import { db } from "@/db";
import { products, reviews } from "@/db/schema";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const allProducts = await db.select().from(products);
    const allReviews = await db.select().from(reviews);
    
    // If DB empty, fallback to static data response
    if (allProducts.length === 0) {
      const { products: staticProducts } = await import("@/data/products");
      return Response.json({ products: staticProducts, source: "static" });
    }

    // Attach reviews
    const withReviews = allProducts.map(p => ({
      ...p,
      reviews: allReviews.filter(r => r.productId === p.id)
    }));

    return Response.json({ products: withReviews, source: "db" });
  } catch (e) {
    console.error("products GET error", e);
    try {
      const { products: staticProducts } = await import("@/data/products");
      return Response.json({ products: staticProducts, source: "fallback" });
    } catch {
      return Response.json({ error: "Failed to fetch products" }, { status: 500 });
    }
  }
}
