import { db } from "@/db";
import { orders } from "@/db/schema";
import { desc } from "drizzle-orm";
import { CONTACT } from "@/lib/constants";

export const dynamic = "force-dynamic";

function genOrderCode() {
  return "UP-" + Math.random().toString(36).substring(2, 8).toUpperCase() + "-" + Date.now().toString().slice(-4);
}

export async function GET() {
  try {
    const allOrders = await db.select().from(orders).orderBy(desc(orders.createdAt)).limit(100);
    return Response.json({ orders: allOrders });
  } catch (e) {
    console.error(e);
    return Response.json({ error: "Failed to fetch orders" }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { customerName, email, creatorHandle, phone, subtotal, tax, total, items, paymentMethod } = body;

    if (!customerName || !email || !items) {
      return Response.json({ error: "Missing required fields" }, { status: 400 });
    }

    const orderCode = genOrderCode();

    const [created] = await db.insert(orders).values({
      orderCode,
      customerName,
      email,
      creatorHandle: creatorHandle || "@creator",
      phone: phone || "",
      status: paymentMethod === "paypal" ? "awaiting_paypal" : "paid",
      subtotal: Math.round(subtotal || 0),
      tax: Math.round(tax || 0),
      total: Math.round(total || 0),
      paymentMethod: paymentMethod || "card",
      paypalEmail: CONTACT.paypalEmail,
      items,
      supportEmail: CONTACT.supportEmail,
      contactPhone: CONTACT.phone,
    }).returning();

    return Response.json({ 
      success: true, 
      order: created,
      paypal: {
        email: CONTACT.paypalEmail,
        link: CONTACT.paypalLink,
        instructions: `Send $${created.total} via PayPal to ${CONTACT.paypalEmail}. Include order code ${orderCode} in notes. Support: ${CONTACT.supportEmail} | Phone: ${CONTACT.phone}`
      }
    });
  } catch (e) {
    console.error("order POST error", e);
    return Response.json({ error: "Failed to create order", details: String(e) }, { status: 500 });
  }
}
