"use client";
import { useEffect, useState } from "react";
import { CONTACT } from "@/lib/constants";

type Order = {
  id: number;
  orderCode: string;
  customerName: string;
  email: string;
  creatorHandle: string;
  phone: string;
  status: string;
  subtotal: number;
  tax: number;
  total: number;
  paymentMethod: string;
  items: any[];
  createdAt: string;
};

type Ticket = {
  id: number;
  name: string;
  email: string;
  phone: string;
  subject: string;
  message: string;
  status: string;
  createdAt: string;
};

export default function AdminPage() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [seedStatus, setSeedStatus] = useState<string>("");
  const [loading, setLoading] = useState(true);

  const load = async () => {
    setLoading(true);
    try {
      const [oRes, tRes] = await Promise.all([fetch("/api/orders"), fetch("/api/contact")]);
      const oData = await oRes.json();
      const tData = await tRes.json();
      setOrders(oData.orders || []);
      setTickets(tData.tickets || []);
    } catch (e) {
      console.error(e);
    }
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const seed = async () => {
    setSeedStatus("Seeding...");
    const res = await fetch("/api/seed", { method: "POST" });
    const data = await res.json();
    setSeedStatus(JSON.stringify(data));
    load();
  };

  return (
    <div className="mx-auto max-w-[1600px] px-6 py-8 lg:px-10">
      <div className="flex flex-wrap items-end justify-between gap-6">
        <div>
          <div className="mono mb-2 inline-flex rounded-full bg-[#0F0F10] px-3 py-1 text-[10px] uppercase tracking-[0.12em] text-white">Backend Dashboard • Option A</div>
          <h1 className="serif text-[44px] leading-[0.9] tracking-[-0.03em]">Admin<br/>Backend</h1>
          <p className="mono mt-3 text-[11px] uppercase tracking-[0.12em] text-[#6B6B73]">PostgreSQL • Drizzle ORM • Orders & Tickets live • Contact {CONTACT.phone} • PayPal {CONTACT.paypalEmail} • Support {CONTACT.supportEmail}</p>
        </div>
        <div className="flex gap-2">
          <button onClick={load} className="mono rounded-full border border-[#E8E6DE] bg-white px-4 py-2 text-[11px] uppercase tracking-[0.12em]">Refresh</button>
          <button onClick={seed} className="mono rounded-full bg-[#E6FF3B] px-4 py-2 text-[11px] uppercase tracking-[0.12em] text-black">Seed Products → DB</button>
        </div>
      </div>

      {seedStatus && <div className="mt-4 rounded-[12px] bg-[#F6F4EF] p-3 mono text-[11px]">{seedStatus}</div>}

      <div className="mt-8 grid gap-8 lg:grid-cols-[1.3fr_0.7fr]">
        <div>
          <div className="flex items-center justify-between">
            <h3 className="serif text-[22px] font-medium">Orders ({orders.length}) — Backend Table: orders</h3>
            <span className="mono text-[11px] uppercase tracking-[0.12em] text-[#6B6B73]">Live from PostgreSQL</span>
          </div>

          <div className="mt-4 space-y-3">
            {loading ? <div className="mono text-[11px] uppercase">Loading orders...</div> : orders.length === 0 ? (
              <div className="rounded-[20px] border border-dashed border-[#E8E6DE] bg-white p-10 text-center">
                <p className="serif text-[20px]">No orders yet</p>
                <p className="mono mt-2 text-[11px] uppercase tracking-[0.12em] text-[#6B6B73]">Checkout will create order in backend • PayPal {CONTACT.paypalEmail}</p>
              </div>
            ) : orders.map(o => (
              <div key={o.id} className="rounded-[20px] border border-[#E8E6DE] bg-white p-5">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="serif text-[18px] font-medium">{o.orderCode}</span>
                      <span className={`mono rounded-full px-2 py-0.5 text-[10px] uppercase ${o.status === "paid" ? "bg-[#22C55E] text-white" : "bg-[#E6FF3B] text-black"}`}>{o.status}</span>
                      <span className="mono rounded-full border border-[#E8E6DE] bg-[#F6F4EF] px-2 py-0.5 text-[10px] uppercase">{o.paymentMethod}</span>
                    </div>
                    <div className="mono mt-1 text-[11px] text-[#6B6B73]">{o.customerName} • {o.email} • {o.creatorHandle} • {o.phone || "No phone"} • {new Date(o.createdAt).toLocaleString()}</div>
                  </div>
                  <div className="text-right">
                    <div className="serif text-[18px] font-medium">${o.total}</div>
                    <div className="mono text-[10px] uppercase tracking-[0.08em] text-[#9A9AA0]">Sub ${o.subtotal} + Tax ${o.tax}</div>
                  </div>
                </div>
                <div className="mt-4 flex flex-wrap gap-2">
                  {o.items?.map((it: any, idx: number) => (
                    <div key={idx} className="mono flex items-center gap-2 rounded-full border border-[#E8E6DE] bg-[#F6F4EF] px-3 py-1 text-[11px]">
                      <span>{it.title} ×{it.quantity}</span><span className="opacity-60">${it.price}</span>
                    </div>
                  ))}
                </div>
                {o.paymentMethod === "paypal" && (
                  <div className="mt-3 rounded-[12px] bg-[#E6FF3B] p-3 mono text-[11px]">PayPal: verify payment to {CONTACT.paypalEmail} with note {o.orderCode} • Support {CONTACT.supportEmail} • Contact {CONTACT.phone}</div>
                )}
              </div>
            ))}
          </div>
        </div>

        <div>
          <h3 className="serif text-[22px] font-medium">Support Tickets ({tickets.length})</h3>
          <p className="mono mt-1 text-[11px] uppercase tracking-[0.12em] text-[#6B6B73]">Table: support_tickets • Support {CONTACT.supportEmail}</p>
          <div className="mt-4 space-y-3">
            {tickets.length === 0 ? (
              <div className="rounded-[20px] border border-dashed border-[#E8E6DE] bg-white p-8 text-center mono text-[11px] uppercase tracking-[0.12em] text-[#6B6B73]">No tickets • Contact form creates backend ticket</div>
            ) : tickets.map(t => (
              <div key={t.id} className="rounded-[20px] border border-[#E8E6DE] bg-white p-5">
                <div className="flex items-center justify-between">
                  <span className="serif text-[16px] font-medium">{t.name}</span>
                  <span className="mono rounded-full bg-[#0F0F10] px-2 py-0.5 text-[10px] uppercase text-white">{t.status}</span>
                </div>
                <div className="mono mt-1 text-[11px] text-[#6B6B73]">{t.email} • {t.phone} • {new Date(t.createdAt).toLocaleString()}</div>
                <div className="mono mt-2 text-[12px] font-medium uppercase tracking-[0.08em]">{t.subject}</div>
                <p className="mt-2 text-[13px] leading-[1.5] text-[#3F3F46]">{t.message}</p>
              </div>
            ))}
          </div>

          <div className="mt-8 rounded-[20px] bg-[#0F0F10] p-6 text-white">
            <div className="mono text-[11px] uppercase tracking-[0.12em] opacity-60">Option A — Contact Matrix</div>
            <div className="mt-4 space-y-3 text-[13px]">
              <div className="flex justify-between gap-4"><span className="mono text-[11px] uppercase opacity-60">Contact</span><a href={`tel:${CONTACT.phone}`} className="font-medium text-[#E6FF3B]">{CONTACT.phone}</a></div>
              <div className="flex justify-between gap-4"><span className="mono text-[11px] uppercase opacity-60">PayPal</span><span className="font-medium">{CONTACT.paypalEmail}</span></div>
              <div className="flex justify-between gap-4"><span className="mono text-[11px] uppercase opacity-60">Support</span><span className="font-medium">{CONTACT.supportEmail}</span></div>
              <div className="flex justify-between gap-4"><span className="mono text-[11px] uppercase opacity-60">PayPal Link</span><a href={CONTACT.paypalLink} className="truncate font-medium underline">{CONTACT.paypalLink}</a></div>
            </div>
            <div className="mt-6 grid grid-cols-2 gap-2">
              <a href="/api/products" className="mono rounded-full border border-white/20 px-3 py-2 text-center text-[11px] uppercase tracking-[0.1em]">/api/products</a>
              <a href="/api/orders" className="mono rounded-full border border-white/20 px-3 py-2 text-center text-[11px] uppercase tracking-[0.1em]">/api/orders</a>
              <a href="/api/paypal" className="mono rounded-full border border-white/20 px-3 py-2 text-center text-[11px] uppercase tracking-[0.1em]">/api/paypal</a>
              <a href="/api/contact" className="mono rounded-full border border-white/20 px-3 py-2 text-center text-[11px] uppercase tracking-[0.1em]">/api/contact</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
