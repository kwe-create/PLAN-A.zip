"use client";
import Link from "next/link";
import { motion } from "framer-motion";
import { products, categories } from "@/data/products";
import { ProductCard } from "@/components/product-card";
import { CONTACT } from "@/lib/constants";

export default function HomePage() {
  const featured = products.filter((p) => p.featured).slice(0, 6);

  return (
    <div className="overflow-clip">
      {/* HERO */}
      <section className="relative border-b border-[#E8E6DE] bg-[#FCFCF8]">
        <div className="absolute inset-0 grid-lines opacity-[0.45]" />
        <div className="absolute inset-0 bg-[radial-gradient(100%_60%_at_50%_0%,#E6FF3B_0%,transparent_60%)] opacity-40" />
        <div className="relative mx-auto grid max-w-[1600px] grid-cols-1 gap-0 px-6 pb-10 pt-10 lg:grid-cols-[1.1fr_0.9fr] lg:px-10 lg:pb-20 lg:pt-20">
          <div className="relative">
            <div className="mono mb-6 inline-flex items-center gap-2 rounded-full border border-[#E8E6DE] bg-white px-3 py-1 text-[10px] uppercase tracking-[0.14em]">
              <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-[#FF3B1F]" />
              340+ creators • 127M views managed this month
            </div>

            <h1 className="serif text-[clamp(44px,8vw,124px)] font-[680] leading-[0.85] tracking-[-0.04em]">
              Social
              <br />
              <span className="relative inline-block">
                <span className="relative z-10">management</span>
                <span className="absolute bottom-[0.15em] left-0 right-0 z-0 h-[0.28em] bg-[#E6FF3B]"></span>
              </span>
              <br />
              <span className="font-[300] italic tracking-[-0.03em]">for creators</span>
              <br />
              <span className="text-[#FF3B1F]">who mean</span> business.
            </h1>

            <p className="mt-8 max-w-[48ch] text-[18px] leading-[1.55] tracking-[-0.01em] text-[#3F3F46]">
              UPSCORE is the operating system behind 6- and 7-figure creators. We grow, produce, and monetize your content while you focus on creating. No fluff agency. Real results.
              <span className="mt-3 block mono text-[11px] uppercase tracking-[0.1em] text-[#6B6B73]">Option A • Contact {CONTACT.phone} • PayPal {CONTACT.paypalEmail} • Support {CONTACT.supportEmail} • Backend Live</span>
            </p>

            <div className="mt-10 flex flex-wrap items-center gap-3">
              <Link href="/shop" className="group inline-flex items-center gap-3 rounded-full bg-[#0F0F10] px-7 py-4 text-[14px] font-medium text-white transition hover:bg-black">
                Shop The Drops
                <span className="grid h-6 w-6 place-items-center rounded-full bg-white text-black transition group-hover:translate-x-0.5">→</span>
              </Link>
              <div className="flex items-center gap-3 rounded-full border border-[#E8E6DE] bg-white px-4 py-3">
                <div className="flex -space-x-2">
                  {[1, 2, 3].map((i) => (
                    <img key={i} src={`https://i.pravatar.cc/100?img=${10 + i}`} className="h-7 w-7 rounded-full border-2 border-white" alt="" />
                  ))}
                </div>
                <div className="mono text-[11px] leading-tight">
                  <div className="font-medium text-black">Trusted by 1.2M+ audience</div>
                  <div className="text-[#6B6B73]">4.9/5 from 412 reviews</div>
                </div>
              </div>
            </div>

            <div className="mt-14 grid grid-cols-3 gap-6 border-t border-[#E8E6DE] pt-8 lg:max-w-[520px]">
              {[
                { k: "+187%", v: "Avg reach lift in 60 days" },
                { k: "$3.2M", v: "Brand deals closed last q" },
                { k: "12h", v: "Avg inbox response time" },
              ].map((s) => (
                <div key={s.k}>
                  <div className="serif text-[32px] font-medium tracking-tight">{s.k}</div>
                  <div className="mono mt-1 text-[11px] uppercase leading-[1.3] tracking-[0.08em] text-[#6B6B73]">{s.v}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Visual Mock */}
          <div className="relative mt-10 lg:mt-0 lg:pl-12">
            <div className="relative rounded-[32px] border border-[#E8E6DE] bg-white p-3 shadow-[0_40px_80px_rgba(15,15,16,0.12)]">
              <div className="overflow-hidden rounded-[22px] bg-[#0F0F10] text-white">
                <div className="flex items-center justify-between border-b border-white/10 px-6 py-4">
                  <span className="mono text-[11px] uppercase tracking-[0.14em] opacity-60">Dashboard — Maya Chen</span>
                  <span className="mono text-[11px]">● Live now</span>
                </div>
                <div className="grid gap-3 p-4 md:grid-cols-2">
                  <div className="rounded-[16px] bg-white/[0.06] p-4 backdrop-blur">
                    <div className="mono text-[10px] uppercase tracking-[0.12em] opacity-60">Reach — 7 days</div>
                    <div className="mt-3 flex items-baseline gap-2">
                      <span className="serif text-[36px]">4.2M</span>
                      <span className="mono text-[12px] text-[#E6FF3B]">+187%</span>
                    </div>
                    <div className="mt-4 h-[48px] w-full">
                      <svg viewBox="0 0 100 32" className="h-full w-full">
                        <path d="M0 24 C 10 18, 20 26, 30 14 C 40 8, 50 16, 60 10 C 70 6, 80 12, 100 2" fill="none" stroke="#E6FF3B" strokeWidth="2" strokeLinecap="round"/>
                      </svg>
                    </div>
                  </div>
                  <div className="rounded-[16px] bg-[#E6FF3B] p-4 text-black">
                    <div className="mono text-[10px] uppercase tracking-[0.12em] opacity-70">Next Drop</div>
                    <div className="serif mt-2 text-[20px] leading-[1.1]">Viral Reels Lab — 3 ready to post</div>
                    <div className="mt-4 flex gap-2">
                      <div className="h-10 flex-1 rounded-full bg-black/10" />
                      <div className="h-10 flex-1 rounded-full bg-black text-[12px] grid place-items-center text-white font-medium">Post →</div>
                    </div>
                  </div>
                  <div className="rounded-[16px] bg-white/[0.06] p-4">
                    <div className="mono text-[10px] uppercase tracking-[0.12em] opacity-60">Inbox — Deals</div>
                    <div className="mt-3 space-y-2">
                      {["Gymshark — $8.5k", "Rhode — $12k", "Stanley — $5k"].map((b) => (
                        <div key={b} className="flex items-center justify-between rounded-full bg-white/[0.08] px-3 py-2 text-[12px]"><span>{b}</span><span>→</span></div>
                      ))}
                    </div>
                  </div>
                  <div className="overflow-hidden rounded-[16px] bg-white">
                    <img src="https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?q=80&w=600&auto=format&fit=crop" alt="" className="h-[116px] w-full object-cover" />
                    <div className="p-3">
                      <div className="mono text-[10px] uppercase">Reel — Hook tested: 9.2/10</div>
                      <div className="mt-1 text-[13px] leading-tight font-medium">“3 editing tricks I wish I knew sooner”</div>
                    </div>
                  </div>
                </div>
              </div>
              {/* floating cards */}
              <motion.div initial={{ y: 10 }} animate={{ y: -6 }} transition={{ duration: 3, repeat: Infinity, repeatType: "reverse", ease: "easeInOut" }} className="absolute -left-6 top-[28%] hidden rounded-2xl border border-[#E8E6DE] bg-white px-4 py-3 shadow-[0_20px_40px_rgba(0,0,0,0.08)] md:flex items-center gap-3">
                <div className="h-8 w-8 rounded-full bg-[#FF3B1F]" />
                <div><div className="mono text-[10px] uppercase text-[#6B6B73]">Comment managed</div><div className="text-[13px] font-medium">+2,847 today</div></div>
              </motion.div>
              <motion.div initial={{ y: -10 }} animate={{ y: 6 }} transition={{ duration: 3.5, repeat: Infinity, repeatType: "reverse", ease: "easeInOut" }} className="absolute -right-8 bottom-[20%] hidden rounded-2xl border border-[#E8E6DE] bg-[#0F0F10] px-4 py-3 text-white shadow-[0_20px_40px_rgba(0,0,0,0.15)] md:flex items-center gap-3">
                <div className="grid h-8 w-8 place-items-center rounded-full bg-[#E6FF3B] text-black">★</div>
                <div><div className="mono text-[10px] uppercase opacity-60">Retention</div><div className="text-[13px] font-medium">41% — top 1%</div></div>
              </motion.div>
            </div>
          </div>
        </div>
      </section>

      {/* COLLECTIONS */}
      <section id="collections" className="mx-auto max-w-[1600px] px-6 py-16 lg:px-10 lg:py-24">
        <div className="flex flex-wrap items-end justify-between gap-6">
          <div>
            <div className="mono mb-3 text-[11px] uppercase tracking-[0.14em] text-[#6B6B73]">Curated Systems</div>
            <h2 className="serif text-[44px] leading-[0.9] tracking-[-0.03em] md:text-[64px]">Built for every<br />stage of <span className="font-light italic">creator growth.</span></h2>
          </div>
          <p className="max-w-[36ch] text-[16px] leading-[1.5] text-[#6B6B73]">Pick your lever — growth, production, monetization, or systems. Each drop is a proven playbook, not theory.</p>
        </div>

        <div className="mt-12 grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {categories.slice(1).map((cat) => {
            const meta = {
              growth: { bg: "#0F0F10", fg: "#FCFCF8", accent: "#E6FF3B", desc: "Grow faster while doing less. Strategy + community + analytics.", visual: "▲" },
              production: { bg: "#FF3B1F", fg: "#FCFCF8", accent: "#FFFFFF", desc: "Scroll-stoppers engineered to retain. Editing, thumbnails, UGC.", visual: "◐" },
              monetization: { bg: "#7C5CFF", fg: "#FCFCF8", accent: "#E6FF3B", desc: "Turn audience into income. Brand deals, shop, ghostwriting.", visual: "⬢" },
              systems: { bg: "#FEFAE0", fg: "#0F0F10", accent: "#0F0F10", desc: "The operating system behind 6-figure creator businesses.", visual: "◧" },
            }[cat.id as "growth" | "production" | "monetization" | "systems"];
            if (!meta) return null;
            return (
              <Link key={cat.id} href={`/shop?cat=${cat.id}`} className="group relative overflow-hidden rounded-[28px] border border-[#E8E6DE] p-7" style={{ background: meta.bg, color: meta.fg }}>
                <div className="flex items-start justify-between">
                  <div className="mono text-[11px] uppercase tracking-[0.14em] opacity-70">{cat.count} Drops</div>
                  <div className="grid h-8 w-8 place-items-center rounded-full border border-current text-[14px] transition group-hover:bg-white group-hover:text-black">↗</div>
                </div>
                <div className="mt-16 text-[56px] leading-none opacity-20">{meta.visual}</div>
                <h3 className="serif mt-3 text-[28px] font-medium leading-[0.95] tracking-tight">{cat.label}</h3>
                <p className="mt-3 text-[14px] leading-[1.4] opacity-80">{meta.desc}</p>
                <div className="absolute bottom-0 left-0 h-1 w-full origin-left scale-x-0 bg-[currentColor] transition duration-500 group-hover:scale-x-100" />
              </Link>
            );
          })}
        </div>
      </section>

      {/* FEATURED GRID */}
      <section className="border-y border-[#E8E6DE] bg-[#F6F4EF]">
        <div className="mx-auto max-w-[1600px] px-6 py-16 lg:px-10 lg:py-20">
          <div className="flex items-center justify-between">
            <h2 className="serif text-[34px] font-medium tracking-tight">Featured Drops</h2>
            <Link href="/shop" className="mono rounded-full border border-[#E8E6DE] bg-white px-5 py-2 text-[11px] uppercase tracking-[0.14em]">View All →</Link>
          </div>
          <div className="mt-8 grid gap-5 md:grid-cols-2 lg:grid-cols-3">
            {featured.map((p, i) => (
              <ProductCard key={p.id} product={p} index={i} />
            ))}
          </div>
        </div>
      </section>

      {/* Process */}
      <section id="process" className="mx-auto max-w-[1600px] px-6 py-16 lg:px-10 lg:py-24">
        <div className="grid gap-10 lg:grid-cols-[0.9fr_1.1fr]">
          <div>
            <div className="mono mb-3 text-[11px] uppercase tracking-[0.14em] text-[#6B6B73]">How UPSCORE Works</div>
            <h2 className="serif text-[48px] leading-[0.9] tracking-[-0.03em]">We plug into<br />your workflow<br /><span className="italic font-light">in 48 hours.</span></h2>
            <div className="mt-8 space-y-6 border-t border-[#E8E6DE] pt-8">
              {[
                { n: "01", t: "Audit & Map", d: "We teardown your profiles, content, and revenue. Then map your next 90 days." },
                { n: "02", t: "System Install", d: "Calendar, hooks, posting ops, community — installed into your stack (Slack + Notion)." },
                { n: "03", t: "Grow & Report", d: "Weekly Loom breakdowns, retention analysis, and deal pipeline. You see lift in 14 days." },
              ].map((s) => (
                <div key={s.n} className="flex gap-6">
                  <div className="mono text-[12px] text-[#9A9AA0]">{s.n}</div>
                  <div>
                    <div className="serif text-[20px] font-medium">{s.t}</div>
                    <div className="mt-1 text-[14px] leading-[1.5] text-[#6B6B73]">{s.d}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
          <div className="grid gap-4 md:grid-cols-2">
            <div className="rounded-[28px] bg-[#0F0F10] p-8 text-white">
              <div className="mono text-[11px] uppercase tracking-[0.14em] opacity-60">Trusted Creators</div>
              <div className="mt-6 space-y-4">
                {[
                  { name: "Maya Chen · 1.1M", metric: "+302K in 90d" },
                  { name: "Jordan Park · 523K", metric: "11 brand deals" },
                  { name: "Ava Looks · 1.2M", metric: "19.4M views/mo" },
                ].map((c) => (
                  <div key={c.name} className="flex items-center justify-between border-b border-white/10 py-3">
                    <span className="text-[14px]">{c.name}</span><span className="mono text-[11px] text-[#E6FF3B]">{c.metric}</span>
                  </div>
                ))}
              </div>
              <div className="mt-8 rounded-2xl bg-white/[0.06] p-4">
                <div className="mono text-[10px] uppercase tracking-[0.12em] opacity-60">Average Client Review</div>
                <div className="mt-2 flex gap-1 text-[#E6FF3B]">★★★★★</div>
                <p className="mt-2 text-[14px] leading-[1.4]">“UPSCORE made me a full-time creator. I finally work 4 days a week.”</p>
                <p className="mono mt-2 text-[11px] opacity-60">@mayamakes — 842K</p>
              </div>
            </div>
            <div className="grid gap-4">
              <div className="rounded-[28px] border border-[#E8E6DE] bg-white p-6">
                <div className="mono text-[11px] uppercase tracking-[0.12em]">Stack Comparison</div>
                <div className="mt-6 space-y-3 text-[13px]">
                  <div className="flex justify-between"><span className="text-[#6B6B73]">DIY editing + management</span><span className="font-medium line-through opacity-40">~$3.5K/mo</span></div>
                  <div className="flex justify-between"><span className="text-[#6B6B73]">Traditional agency</span><span className="font-medium line-through opacity-40">~$6K/mo</span></div>
                  <div className="flex justify-between rounded-full bg-[#E6FF3B] px-3 py-2 font-medium"><span>UPSCORE Engine</span><span>$2,495</span></div>
                </div>
                <p className="mono mt-6 text-[10px] uppercase leading-[1.4] text-[#9A9AA0]">48h kickoff • Cancel anytime • Dedicated Slack • No long contracts</p>
              </div>
              <div className="rounded-[28px] bg-[#FF3B1F] p-6 text-white">
                <div className="mono text-[11px] uppercase tracking-[0.12em] opacity-80">Founder Note</div>
                <p className="serif mt-4 text-[22px] leading-[1.1]">We only win if you grow. That’s why we obsess over retention, not vanity metrics.</p>
                <p className="mono mt-6 text-[11px] opacity-70">— Alex Rivera, Founder</p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
