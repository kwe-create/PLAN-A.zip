import { CONTACT } from "@/lib/constants";

export function Footer() {
  return (
    <footer className="border-t border-[#E8E6DE] bg-[#0F0F10] text-[#FCFCF8]">
      <div className="mx-auto max-w-[1600px] px-6 py-16 lg:px-10">
        <div className="grid gap-12 md:grid-cols-[1.5fr_1fr_1fr_1.2fr]">
          <div>
            <div className="flex items-center gap-2">
              <div className="grid h-8 w-8 place-items-center rounded-full bg-white text-[13px] font-bold text-black">U</div>
              <span className="serif text-[22px] font-semibold tracking-[-0.02em]">UPSCORE</span>
            </div>
            <p className="mt-6 max-w-sm text-[15px] leading-[1.6] text-[#A8A8B0]">
              Social media management for creators who treat content like a business. Not an agency — your unfair advantage.
            </p>
            <div className="mt-8 rounded-[16px] border border-[#2A2A30] bg-[#1A1A1E] p-4">
              <p className="mono mb-3 text-[10px] uppercase tracking-[0.14em] text-[#6B6B73]">Option A — Direct Contact & Payments</p>
              <div className="space-y-2 text-[13px]">
                <div className="flex items-center justify-between">
                  <span className="mono text-[11px] uppercase tracking-[0.1em] text-[#6B6B73]">Contact</span>
                  <a href={`tel:${CONTACT.phone}`} className="font-medium text-[#E6FF3B] hover:underline">{CONTACT.phone}</a>
                </div>
                <div className="flex items-center justify-between">
                  <span className="mono text-[11px] uppercase tracking-[0.1em] text-[#6B6B73]">PayPal</span>
                  <a href={`mailto:${CONTACT.paypalEmail}`} className="font-medium text-white hover:underline">{CONTACT.paypalEmail}</a>
                </div>
                <div className="flex items-center justify-between">
                  <span className="mono text-[11px] uppercase tracking-[0.1em] text-[#6B6B73]">Support</span>
                  <a href={`mailto:${CONTACT.supportEmail}`} className="font-medium text-white hover:underline">{CONTACT.supportEmail}</a>
                </div>
                <div className="mono mt-2 text-[10px] uppercase tracking-[0.08em] text-[#5A5A64]">PayPal preferred • Instant verification • 2h response</div>
              </div>
            </div>
            <div className="mono mt-6 flex gap-6 text-[11px] uppercase tracking-[0.12em] text-[#6B6B73]">
              <span>© 2026 UPSCORE</span>
              <span>Los Angeles — Remote</span>
            </div>
          </div>
          <div>
            <p className="mono mb-6 text-[11px] uppercase tracking-[0.14em] text-[#6B6B73]">Shop</p>
            <ul className="space-y-3 text-[14px] text-[#D6D6DC]">
              <li><a href="/shop" className="hover:text-white">All Drops</a></li>
              <li><a href="/shop?cat=growth" className="hover:text-white">Growth & Management</a></li>
              <li><a href="/shop?cat=production" className="hover:text-white">Content Production</a></li>
              <li><a href="/shop?cat=monetization" className="hover:text-white">Monetization</a></li>
              <li><a href="/shop?cat=systems" className="hover:text-white">Systems</a></li>
            </ul>
          </div>
          <div>
            <p className="mono mb-6 text-[11px] uppercase tracking-[0.14em] text-[#6B6B73]">Backend & Support</p>
            <ul className="space-y-3 text-[14px] text-[#D6D6DC]">
              <li><a href="/contact" className="hover:text-white">Contact / Help →</a></li>
              <li><a href="/admin" className="hover:text-white">Admin Dashboard</a></li>
              <li><a href="/api/products" className="hover:text-white mono text-[12px]">API /products</a></li>
              <li><a href="/api/orders" className="hover:text-white mono text-[12px]">API /orders</a></li>
              <li><a href="/api/paypal" className="hover:text-white mono text-[12px]">PayPal Endpoint</a></li>
              <li className="pt-3">
                <span className="inline-flex items-center gap-2 rounded-full bg-[#1A1A1E] border border-[#2A2A30] px-3 py-1 text-[11px]">
                  <span className="h-2 w-2 rounded-full bg-[#22C55E] animate-pulse"></span> Backend Live — PostgreSQL + Drizzle
                </span>
              </li>
            </ul>
          </div>
          <div>
            <p className="mono mb-6 text-[11px] uppercase tracking-[0.14em] text-[#6B6B73]">Get the playbook</p>
            <p className="text-[14px] leading-[1.5] text-[#D6D6DC]">Weekly teardown of what's working for 1M+ creators. No spam. Direct line: {CONTACT.phone}</p>
            <div className="mt-4 flex gap-2">
              <input placeholder="you@email.com" className="w-full rounded-full border border-[#2A2A30] bg-[#1A1A1E] px-4 py-2.5 text-[13px] text-white placeholder:text-[#6B6B73] outline-none focus:border-white" />
              <button className="rounded-full bg-white px-5 py-2.5 text-[13px] font-medium text-black">Join</button>
            </div>
            <div className="mt-6 rounded-[14px] bg-[#E6FF3B] p-4 text-black">
              <div className="mono text-[10px] uppercase tracking-[0.12em] opacity-60">Quick PayPal Checkout</div>
              <p className="serif mt-1 text-[14px] leading-tight font-medium">Prefer PayPal? Send to {CONTACT.paypalEmail} and include order code. Verified in 2h.</p>
              <a href={CONTACT.paypalLink} target="_blank" className="mono mt-2 inline-flex rounded-full bg-black px-3 py-1 text-[10px] uppercase tracking-[0.12em] text-white">Open PayPal →</a>
            </div>
          </div>
        </div>

        <div className="mt-16 flex flex-wrap items-center justify-between gap-4 border-t border-[#1E1E22] pt-8">
          <div className="mono text-[10px] uppercase tracking-[0.16em] text-[#6B6B73]">
            Built for creators scaling to 7-figures and beyond. • Contact {CONTACT.phone} • PayPal {CONTACT.paypalEmail} • Support {CONTACT.supportEmail}
          </div>
          <div className="flex gap-3">
            {["IG @upscore", "TikTok", "YouTube", "LinkedIn", "API Docs"].map((s) => (
              <span key={s} className="rounded-full border border-[#2A2A30] px-3 py-1 text-[11px] text-[#A8A8B0]">{s}</span>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
}
