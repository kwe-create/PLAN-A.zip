import { db } from "@/db";
import { products, reviews } from "@/db/schema";
import { products as staticProducts } from "@/data/products";

export const dynamic = "force-dynamic";

export async function POST() {
  try {
    // Clear existing
    await db.delete(reviews);
    await db.delete(products);

    for (const p of staticProducts) {
      await db.insert(products).values({
        id: p.id,
        slug: p.slug,
        title: p.title,
        subtitle: p.subtitle,
        description: p.description,
        longDescription: p.longDescription,
        price: p.price,
        compareAtPrice: p.compareAtPrice || null,
        billing: p.billing,
        category: p.category,
        tags: p.tags,
        featured: p.featured,
        isNew: p.isNew || false,
        isBestSeller: p.isBestSeller || false,
        color: p.color,
        accent: p.accent,
        image: p.image,
        gallery: p.gallery,
        features: p.features,
        includes: p.includes,
        metrics: p.metrics,
        rating: p.rating.toString(),
        reviewCount: p.reviewCount,
        delivery: p.delivery,
        turnaround: p.turnaround,
      });

      for (const r of p.reviews) {
        await db.insert(reviews).values({
          id: r.id,
          productId: p.id,
          author: r.author,
          avatar: r.avatar,
          handle: r.handle,
          role: r.role,
          rating: r.rating,
          date: r.date,
          text: r.text,
          followers: r.followers,
          verified: r.verified || false,
        });
      }
    }

    const countProducts = (await db.select().from(products)).length;
    const countReviews = (await db.select().from(reviews)).length;

    return Response.json({ success: true, seeded: { products: countProducts, reviews: countReviews } });
  } catch (e) {
    console.error(e);
    return Response.json({ error: String(e) }, { status: 500 });
  }
}

export async function GET() {
  return POST();
}
