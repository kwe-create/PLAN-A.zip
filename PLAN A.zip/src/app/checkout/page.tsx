"use client";
import { useCart } from "@/components/cart-context";
import Link from "next/link";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { CONTACT } from "@/lib/constants";

export default function CheckoutPage() {
  const { items, subtotal, clear } = useCart();
  const [email, setEmail] = useState("");
  const [name, setName] = useState("");
  const [handle, setHandle] = useState("");
  const [phone, setPhone] = useState("");
  const [paymentMethod, setPaymentMethod] = useState<"card" | "paypal">("paypal");
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  const total = subtotal;
  const tax = Math.round(subtotal * 0.08);
  const grand = total + tax;

  const handlePay = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          customerName: name,
          email,
          creatorHandle: handle,
          phone,
          subtotal,
          tax,
          total: grand,
          paymentMethod,
          items: items.map(i => ({
            productId: i.product.id,
            title: i.product.title,
            slug: i.product.slug,
            price: i.product.price,
            quantity: i.quantity,
            image: i.product.image,
          }))
        })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed");
      
      // store order code for success page
      localStorage.setItem("upscore_last_order", JSON.stringify(data));
      clear();
      router.push(`/checkout/success?code=${data.order.orderCode}&method=${paymentMethod}`);
    } catch (err) {
      console.error(err);
      alert("Order failed - check backend / contact support: " + CONTACT.supportEmail);
    } finally {
      setLoading(false);
    }
  };

  if (items.length === 0) {
    return (
      <div className="mx-auto max-w-[1600px] px-6 py-20 lg:px-10">
        <div className="grid place-items-center rounded-[32px] border border-[#E8E6DE] bg-white py-24 text-center">
          <p className="serif text-[36px]">Your cart is empty</p>
          <p className="mono mt-2 text-[11px] uppercase tracking-[0.12em] text-[#6B6B73]">Add a drop to checkout</p>
          <Link href="/shop" className="mono mt-6 inline-flex rounded-full bg-black px-6 py-3 text-[11px] uppercase tracking-[0.14em] text-white">Browse Drops</Link>
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-[1600px] px-6 py-10 lg:px-10">
      <div className="grid gap-10 lg:grid-cols-[1.1fr_0.9fr]">
        <div>
          <div className="mono mb-6 flex items-center gap-2 text-[11px] uppercase tracking-[0.12em] text-[#6B6B73]"><Link href="/shop">Shop</Link><span>/</span><span className="text-black">Checkout</span> <span className="ml-2 rounded-full bg-[#E6FF3B] px-2 py-0.5 text-black">Option A Backend Live</span></div>
          <h1 className="serif text-[44px] leading-[0.9] tracking-[-0.03em]">Checkout</h1>
          <p className="mono mt-3 text-[11px] uppercase tracking-[0.12em] text-[#6B6B73]">Contact {CONTACT.phone} • PayPal {CONTACT.paypalEmail} • Support {CONTACT.supportEmail}</p>

          <form onSubmit={handlePay} className="mt-10 space-y-6">
            <div className="rounded-[24px] border border-[#E8E6DE] bg-white p-6">
              <h3 className="mono mb-5 text-[11px] uppercase tracking-[0.14em]">Creator Details</h3>
              <div className="grid gap-4 md:grid-cols-2">
                <div>
                  <label className="mono mb-2 block text-[11px] uppercase tracking-[0.12em] text-[#6B6B73]">Full Name</label>
                  <input required value={name} onChange={(e) => setName(e.target.value)} placeholder="Maya Chen" className="w-full rounded-full border border-[#E8E6DE] bg-[#FCFCF8] px-5 py-3 text-[14px] outline-none focus:border-black" />
                </div>
                <div>
                  <label className="mono mb-2 block text-[11px] uppercase tracking-[0.12em] text-[#6B6B73]">Phone (Option A)</label>
                  <input value={phone} onChange={(e) => setPhone(e.target.value)} placeholder={CONTACT.phone} className="w-full rounded-full border border-[#E8E6DE] bg-[#FCFCF8] px-5 py-3 text-[14px] outline-none focus:border-black" />
                </div>
                <div>
                  <label className="mono mb-2 block text-[11px] uppercase tracking-[0.12em] text-[#6B6B73]">Email (for onboarding)</label>
                  <input required type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="maya@studio.com" className="w-full rounded-full border border-[#E8E6DE] bg-[#FCFCF8] px-5 py-3 text-[14px] outline-none focus:border-black" />
                </div>
                <div>
                  <label className="mono mb-2 block text-[11px] uppercase tracking-[0.12em] text-[#6B6B73]">Creator Handle</label>
                  <input required value={handle} onChange={(e) => setHandle(e.target.value)} placeholder="@mayamakes" className="w-full rounded-full border border-[#E8E6DE] bg-[#FCFCF8] px-5 py-3 text-[14px] outline-none focus:border-black" />
                </div>
              </div>
            </div>

            <div className="rounded-[24px] border border-[#E8E6DE] bg-white p-6">
              <h3 className="mono mb-5 text-[11px] uppercase tracking-[0.14em]">Payment Method — Option A</h3>
              <div className="grid gap-3">
                <button type="button" onClick={() => setPaymentMethod("paypal")} className={`flex items-center justify-between rounded-[16px] border px-5 py-4 text-left transition ${paymentMethod === "paypal" ? "border-black bg-black text-white" : "border-[#E8E6DE] bg-[#F6F4EF] hover:border-black/20"}`}>
                  <div>
                    <div className="flex items-center gap-2"><span className="text-[14px] font-medium">PayPal</span><span className={`mono rounded-full px-2 py-0.5 text-[10px] uppercase ${paymentMethod === "paypal" ? "bg-white text-black" : "bg-black text-white"}`}>Recommended</span></div>
                    <div className={`mono mt-1 text-[11px] ${paymentMethod === "paypal" ? "text-white/60" : "text-[#6B6B73]"}`}>Send to {CONTACT.paypalEmail} • Verified in 2h • Includes buyer protection</div>
                  </div>
                  <div className={`grid h-5 w-5 place-items-center rounded-full border ${paymentMethod === "paypal" ? "border-white bg-white text-black" : "border-[#D0CDC6]"}`}>{paymentMethod === "paypal" && "✓"}</div>
                </button>
                <button type="button" onClick={() => setPaymentMethod("card")} className={`flex items-center justify-between rounded-[16px] border px-5 py-4 text-left transition ${paymentMethod === "card" ? "border-black bg-black text-white" : "border-[#E8E6DE] bg-[#F6F4EF] hover:border-black/20"}`}>
                  <div>
                    <div className="text-[14px] font-medium">Card • Apple Pay • Google Pay</div>
                    <div className={`mono mt-1 text-[11px] ${paymentMethod === "card" ? "text-white/60" : "text-[#6B6B73]"}`}>Stripe Secure • TLS 1.3 • Instant onboarding</div>
                  </div>
                  <div className={`grid h-5 w-5 place-items-center rounded-full border ${paymentMethod === "card" ? "border-white bg-white text-black" : "border-[#D0CDC6]"}`}>{paymentMethod === "card" && "✓"}</div>
                </button>
              </div>

              {paymentMethod === "paypal" ? (
                <div className="mt-5 rounded-[16px] bg-[#E6FF3B] p-4 text-black">
                  <div className="mono text-[10px] uppercase tracking-[0.12em]">PayPal Checkout — {CONTACT.paypalEmail}</div>
                  <p className="mt-2 text-[13px] leading-[1.4]">After placing order, you’ll get order code. Send <span className="font-bold">${grand.toLocaleString()}</span> to <span className="font-bold">{CONTACT.paypalEmail}</span> via PayPal. Link: <a href={CONTACT.paypalLink} className="underline">{CONTACT.paypalLink}</a></p>
                  <p className="mono mt-2 text-[11px]">Include order code in PayPal notes. Support: {CONTACT.supportEmail} / {CONTACT.phone}. Verification under 2 hours.</p>
                </div>
              ) : (
                <div className="mt-5 space-y-3">
                  <div className="flex items-center justify-between rounded-full border border-black bg-black px-5 py-3 text-white">
                    <span className="text-[14px]">Card Details</span><span className="mono text-[11px] opacity-60">Stripe Secure</span>
                  </div>
                  <div className="grid gap-3 md:grid-cols-2">
                    <input placeholder="Card number • 4242 4242 4242 4242" className="w-full rounded-full border border-[#E8E6DE] bg-[#FCFCF8] px-5 py-3 text-[13px] outline-none" defaultValue="4242 4242 4242 4242" />
                    <div className="grid grid-cols-2 gap-3">
                      <input placeholder="MM / YY" className="w-full rounded-full border border-[#E8E6DE] bg-[#FCFCF8] px-5 py-3 text-[13px] outline-none" defaultValue="12 / 28" />
                      <input placeholder="CVC" className="w-full rounded-full border border-[#E8E6DE] bg-[#FCFCF8] px-5 py-3 text-[13px] outline-none" defaultValue="123" />
                    </div>
                  </div>
                </div>
              )}
            </div>

            <div className="rounded-[24px] bg-[#0F0F10] p-6 text-white">
              <div className="flex items-center gap-3">
                <input type="checkbox" required className="h-4 w-4 rounded border-white/20 bg-white/10" />
                <span className="text-[13px] leading-[1.4]">I agree to UPSCORE Terms, backend storage, and 48h kickoff. Data stored in PostgreSQL. Support: {CONTACT.supportEmail}</span>
              </div>
              <button disabled={loading} className="mt-6 flex w-full items-center justify-center gap-2 rounded-full bg-white py-4 text-[14px] font-medium text-black transition hover:bg-[#E6FF3B] disabled:opacity-60">
                {loading ? "Creating order in backend..." : paymentMethod === "paypal" ? `Place Order → Pay $${grand.toLocaleString()} via PayPal` : `Pay $${grand.toLocaleString()} → Start in 48h`}
              </button>
              <p className="mono mt-3 text-center text-[10px] uppercase tracking-[0.1em] opacity-60">Backend: orders table • Contact {CONTACT.phone} • PayPal {CONTACT.paypalEmail}</p>
            </div>
          </form>
        </div>

        <div className="lg:sticky lg:top-[88px] lg:h-fit space-y-4">
          <div className="rounded-[28px] border border-[#E8E6DE] bg-white p-6">
            <h3 className="serif text-[22px] font-medium">Order Summary</h3>
            <div className="mt-6 space-y-4">
              {items.map((item) => (
                <div key={item.product.id} className="flex gap-4">
                  <div className="h-16 w-16 overflow-hidden rounded-[12px] bg-[#F6F4EF]"><img src={item.product.image} alt={item.product.title} className="h-full w-full object-cover" /></div>
                  <div className="flex-1">
                    <div className="flex items-start justify-between">
                      <div><div className="serif text-[14px] font-medium leading-tight">{item.product.title}</div><div className="mono mt-1 text-[10px] uppercase tracking-[0.1em] text-[#6B6B73]">{item.product.billing} × {item.quantity}</div></div>
                      <div className="serif text-[14px] font-medium">${(item.product.price * item.quantity).toLocaleString()}</div>
                    </div>
                    <div className="mono mt-1 text-[10px] uppercase tracking-[0.08em] text-[#9A9AA0]">{item.product.delivery}</div>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-6 space-y-2 border-t border-[#E8E6DE] pt-5 text-[13px]">
              <div className="flex justify-between"><span className="text-[#6B6B73]">Subtotal</span><span className="font-medium">${subtotal.toLocaleString()}</span></div>
              <div className="flex justify-between"><span className="text-[#6B6B73]">Tax (estimated)</span><span className="font-medium">${tax.toLocaleString()}</span></div>
              <div className="flex justify-between border-t border-[#E8E6DE] pt-3 text-[16px] font-medium"><span>Total</span><span className="serif text-[20px]">${grand.toLocaleString()}</span></div>
            </div>

            <div className="mt-6 rounded-[16px] bg-[#F6F4EF] p-4">
              <div className="mono text-[11px] uppercase tracking-[0.12em]">Option A — Direct Support</div>
              <ul className="mt-3 space-y-2 text-[13px] leading-[1.4] text-[#3F3F46]">
                <li>• Contact: <a href={`tel:${CONTACT.phone}`} className="font-bold underline">{CONTACT.phone}</a> — 12h response</li>
                <li>• PayPal: {CONTACT.paypalEmail} — send with order code</li>
                <li>• Support: {CONTACT.supportEmail} — technical & billing</li>
                <li>• Backend stores order in PostgreSQL instantly</li>
              </ul>
            </div>
          </div>

          <div className="rounded-[20px] border border-[#E8E6DE] bg-[#0F0F10] p-5 text-white">
            <div className="mono text-[11px] uppercase tracking-[0.12em] opacity-60">Backend Status</div>
            <div className="mt-3 flex items-center gap-2"><span className="h-2 w-2 animate-pulse rounded-full bg-[#22C55E]"></span><span className="mono text-[12px]">PostgreSQL • Drizzle ORM • /api/orders live</span></div>
            <div className="mt-2 mono text-[11px] opacity-60">Orders → admin dashboard • PayPal webhook ready</div>
          </div>
        </div>
      </div>
    </div>
  );
}
