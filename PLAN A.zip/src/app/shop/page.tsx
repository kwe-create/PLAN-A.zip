"use client";
import { useState, useMemo, Suspense } from "react";
import { products, categories } from "@/data/products";
import { ProductCard } from "@/components/product-card";
import { useSearchParams, useRouter } from "next/navigation";

function ShopContent() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const initialCat = searchParams.get("cat") || "all";
  const [activeCat, setActiveCat] = useState(initialCat);
  const [sort, setSort] = useState<"featured" | "price-asc" | "price-desc" | "rating">("featured");
  const [billing, setBilling] = useState<"all" | "monthly" | "one-time">("all");
  const [search, setSearch] = useState("");

  const filtered = useMemo(() => {
    let list = [...products];
    if (activeCat !== "all") list = list.filter((p) => p.category === activeCat);
    if (billing !== "all") list = list.filter((p) => p.billing === billing);
    if (search) {
      const s = search.toLowerCase();
      list = list.filter((p) => p.title.toLowerCase().includes(s) || p.subtitle.toLowerCase().includes(s) || p.tags.some((t) => t.toLowerCase().includes(s)));
    }
    switch (sort) {
      case "price-asc": list.sort((a, b) => a.price - b.price); break;
      case "price-desc": list.sort((a, b) => b.price - a.price); break;
      case "rating": list.sort((a, b) => b.rating - a.rating); break;
      default: list.sort((a, b) => (b.featured ? 1 : 0) - (a.featured ? 1 : 0));
    }
    return list;
  }, [activeCat, sort, billing, search]);

  const changeCat = (cat: string) => {
    setActiveCat(cat);
    const params = new URLSearchParams(searchParams.toString());
    if (cat === "all") params.delete("cat");
    else params.set("cat", cat);
    router.replace(`/shop?${params.toString()}`, { scroll: false });
  };

  return (
    <div className="mx-auto max-w-[1600px] px-6 py-10 lg:px-10 lg:py-12">
      <div className="flex flex-wrap items-end justify-between gap-6 border-b border-[#E8E6DE] pb-10">
        <div>
          <h1 className="serif text-[52px] leading-[0.9] tracking-[-0.03em]">Shop The Drops</h1>
          <p className="mono mt-3 text-[11px] uppercase tracking-[0.12em] text-[#6B6B73]">12 drops • Systems tested on 340+ creators • 4.9/5 avg rating</p>
        </div>
        <div className="flex gap-2">
          <div className="relative">
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search drops, e.g. Reels, Brand Deals..."
              className="w-[300px] rounded-full border border-[#E8E6DE] bg-white px-5 py-3 text-[13px] outline-none placeholder:text-[#9A9AA0] focus:border-black"
            />
            <span className="pointer-events-none absolute right-4 top-1/2 -translate-y-1/2 text-[14px] opacity-40">⌕</span>
          </div>
        </div>
      </div>

      <div className="mt-8 flex flex-wrap gap-8 lg:gap-12">
        {/* Sidebar filters */}
        <div className="w-full lg:w-[240px] lg:shrink-0">
          <div className="sticky top-[88px] space-y-8">
            <div>
              <p className="mono mb-4 text-[11px] uppercase tracking-[0.14em] text-[#6B6B73]">Category</p>
              <div className="space-y-1">
                {categories.map((c) => (
                  <button
                    key={c.id}
                    onClick={() => changeCat(c.id)}
                    className={`flex w-full items-center justify-between rounded-full px-4 py-2.5 text-left text-[14px] transition ${activeCat === c.id ? "bg-[#0F0F10] text-white" : "bg-[#F6F4EF] text-[#3F3F46] hover:bg-[#E8E6DE]"}`}
                  >
                    <span>{c.label}</span><span className="mono text-[11px] opacity-60">{c.count}</span>
                  </button>
                ))}
              </div>
            </div>

            <div>
              <p className="mono mb-4 text-[11px] uppercase tracking-[0.14em] text-[#6B6B73]">Billing</p>
              <div className="flex flex-wrap gap-2">
                {[
                  { id: "all", label: "All" },
                  { id: "monthly", label: "Monthly" },
                  { id: "one-time", label: "One-time" },
                ].map((b) => (
                  <button
                    key={b.id}
                    onClick={() => setBilling(b.id as any)}
                    className={`mono rounded-full border px-4 py-2 text-[11px] uppercase tracking-[0.12em] transition ${billing === b.id ? "border-black bg-black text-white" : "border-[#E8E6DE] bg-white text-[#6B6B73]"}`}
                  >
                    {b.label}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <p className="mono mb-4 text-[11px] uppercase tracking-[0.14em] text-[#6B6B73]">Sort</p>
              <select value={sort} onChange={(e) => setSort(e.target.value as any)} className="w-full rounded-full border border-[#E8E6DE] bg-white px-4 py-2.5 text-[13px] outline-none">
                <option value="featured">Featured First</option>
                <option value="rating">Highest Rated</option>
                <option value="price-asc">Price: Low to High</option>
                <option value="price-desc">Price: High to Low</option>
              </select>
            </div>

            <div className="rounded-[20px] bg-[#0F0F10] p-5 text-white">
              <div className="mono text-[11px] uppercase tracking-[0.12em] opacity-60">Need help choosing?</div>
              <p className="serif mt-3 text-[18px] leading-[1.15]">Not sure which lever to pull first? Get a free growth audit.</p>
              <button className="mono mt-4 rounded-full bg-white px-4 py-2 text-[11px] uppercase tracking-[0.12em] text-black">Book Audit — Free</button>
            </div>
          </div>
        </div>

        <div className="flex-1">
          <div className="mb-6 flex items-center justify-between">
            <p className="mono text-[11px] uppercase tracking-[0.12em] text-[#6B6B73]">Showing {filtered.length} drops</p>
            <div className="mono hidden gap-2 text-[11px] uppercase tracking-[0.12em] text-[#9A9AA0] md:flex">
              <span>Build with UPSCORE</span><span>•</span><span>Scale 7 figures</span>
            </div>
          </div>
          <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">
            {filtered.map((p, i) => (
              <ProductCard key={p.id} product={p} index={i} />
            ))}
          </div>
          {filtered.length === 0 && (
            <div className="grid place-items-center rounded-[28px] border border-dashed border-[#E8E6DE] bg-white py-20 text-center">
              <p className="serif text-[24px]">No drops found.</p>
              <p className="mono mt-2 text-[11px] uppercase tracking-[0.12em] text-[#6B6B73]">Try a different filter or search</p>
              <button onClick={() => { setActiveCat("all"); setBilling("all"); setSearch(""); }} className="mono mt-4 rounded-full bg-black px-5 py-2 text-[11px] uppercase tracking-[0.12em] text-white">Clear Filters</button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default function ShopPage() {
  return (
    <Suspense fallback={<div className="p-10 mono text-[11px] uppercase tracking-[0.12em]">Loading drops...</div>}>
      <ShopContent />
    </Suspense>
  );
}
