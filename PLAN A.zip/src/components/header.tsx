"use client";
import Link from "next/link";
import { useCart } from "./cart-context";
import { usePathname } from "next/navigation";
import { motion } from "framer-motion";
import { useState } from "react";
import { CONTACT } from "@/lib/constants";

export function Header() {
  const { count, openCart } = useCart();
  const pathname = usePathname();
  const [mobileOpen, setMobileOpen] = useState(false);

  const nav = [
    { href: "/shop", label: "Shop" },
    { href: "/#collections", label: "Collections" },
    { href: "/#process", label: "Process" },
    { href: "/contact", label: "Contact" },
    { href: "/admin", label: "Backend" },
  ];

  return (
    <>
      <header className="sticky top-0 z-40 border-b border-[#E8E6DE] bg-[#FCFCF8]/80 glass">
        <div className="mx-auto flex h-[72px] max-w-[1600px] items-center justify-between px-6 lg:px-10">
          <div className="flex items-center gap-10">
            <Link href="/" className="flex items-center gap-2">
              <div className="grid h-8 w-8 place-items-center rounded-full bg-[#0F0F10] text-[13px] font-bold text-white">U</div>
              <span className="serif text-[22px] font-semibold tracking-[-0.02em]">UPSCORE</span>
              <span className="mono ml-1 hidden text-[10px] leading-none tracking-[0.15em] text-[#6B6B73] sm:block">FOR CREATORS®</span>
            </Link>
            <nav className="hidden items-center gap-8 lg:flex">
              {nav.map((n) => (
                <Link
                  key={n.href}
                  href={n.href}
                  className={`mono text-[11px] uppercase tracking-[0.14em] transition-colors hover:text-[#0F0F10] ${pathname === n.href ? "text-[#0F0F10]" : "text-[#6B6B73]"}`}
                >
                  {n.label}
                </Link>
              ))}
            </nav>
          </div>

          <div className="flex items-center gap-3">
            <a href={`tel:${CONTACT.phone}`} className="hidden md:inline-flex mono rounded-full border border-[#E8E6DE] bg-white px-3 py-2 text-[10px] uppercase tracking-[0.12em] text-[#6B6B73] hover:border-black hover:text-black">
              {CONTACT.phone}
            </a>
            <Link href="/shop" className="hidden md:inline-flex">
              <div className="mono rounded-full border border-[#E8E6DE] bg-white px-4 py-2 text-[11px] uppercase tracking-[0.12em] transition hover:bg-[#0F0F10] hover:text-white">
                Browse Drops
              </div>
            </Link>
            <button
              onClick={openCart}
              className="group relative inline-flex h-10 items-center gap-2 rounded-full bg-[#0F0F10] px-4 text-white transition hover:bg-black"
            >
              <span className="mono text-[11px] uppercase tracking-[0.12em]">Cart</span>
              <span className="grid h-5 min-w-5 place-items-center rounded-full bg-white px-1.5 text-[11px] font-bold text-black">
                {count}
              </span>
            </button>
            <button onClick={() => setMobileOpen((v) => !v)} className="grid h-10 w-10 place-items-center rounded-full border border-[#E8E6DE] bg-white lg:hidden">
              <div className="space-y-1">
                <div className="h-px w-4 bg-black" />
                <div className="h-px w-4 bg-black" />
              </div>
            </button>
          </div>
        </div>

        {mobileOpen && (
          <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="border-t border-[#E8E6DE] bg-[#FCFCF8] px-6 py-6 lg:hidden">
            <div className="flex flex-col gap-4">
              {nav.map((n) => (
                <Link key={n.href} href={n.href} onClick={() => setMobileOpen(false)} className="serif text-[28px] tracking-tight">
                  {n.label}
                </Link>
              ))}
              <div className="mt-4 rounded-[16px] bg-[#0F0F10] p-4 text-white">
                <div className="mono text-[10px] uppercase tracking-[0.12em] opacity-60">Direct Contact — Option A</div>
                <div className="mt-2 space-y-1 text-[13px]">
                  <div>Contact: <a href={`tel:${CONTACT.phone}`} className="text-[#E6FF3B]">{CONTACT.phone}</a></div>
                  <div>PayPal: {CONTACT.paypalEmail}</div>
                  <div>Support: {CONTACT.supportEmail}</div>
                </div>
              </div>
              <Link href="/shop" onClick={() => setMobileOpen(false)} className="mono mt-2 inline-flex rounded-full bg-black px-6 py-3 text-[12px] uppercase tracking-[0.14em] text-white">
                Browse Drops →
              </Link>
            </div>
          </motion.div>
        )}
      </header>

      {/* Announcement bar with contact */}
      <div className="relative z-30 overflow-hidden border-b border-[#E8E6DE] bg-[#E6FF3B] py-2">
        <div className="flex">
          <div className="marquee-track flex shrink-0 gap-8">
            {Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="flex items-center gap-8">
                <span className="mono whitespace-nowrap text-[11px] uppercase tracking-[0.12em]">CONTACT {CONTACT.phone} • PAYPAL {CONTACT.paypalEmail} • SUPPORT {CONTACT.supportEmail} • NEW DROP: “OFFLINE AUTOMATION SUITE” • BACKEND LIVE: PostgreSQL + Drizzle • 340+ CREATORS SCALED</span>
                <span className="h-1 w-1 rounded-full bg-black"></span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </>
  );
}
