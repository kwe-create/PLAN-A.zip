"use client";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { Suspense, useEffect, useState } from "react";
import { CONTACT } from "@/lib/constants";

function SuccessContent() {
  const searchParams = useSearchParams();
  const code = searchParams.get("code");
  const method = searchParams.get("method") || "paypal";
  const [orderData, setOrderData] = useState<any>(null);

  useEffect(() => {
    const stored = localStorage.getItem("upscore_last_order");
    if (stored) {
      try { setOrderData(JSON.parse(stored)); } catch {}
    }
  }, []);

  return (
    <div className="mx-auto max-w-[800px] px-6 py-16 text-center lg:px-10 lg:py-24">
      <div className="mx-auto grid h-16 w-16 place-items-center rounded-full bg-[#0F0F10] text-white text-[24px]">✓</div>
      <h1 className="serif mt-8 text-[42px] leading-[0.9] tracking-[-0.03em] md:text-[56px]">You’re in.<br/>Welcome to<br/><span className="bg-[#E6FF3B] px-2">UPSCORE.</span></h1>
      
      {code && (
        <div className="mt-6 inline-flex flex-col items-center rounded-full border border-[#E8E6DE] bg-white px-6 py-3">
          <span className="mono text-[10px] uppercase tracking-[0.14em] text-[#6B6B73]">Order Code • Backend Saved</span>
          <span className="serif text-[20px] font-medium tracking-tight">{code}</span>
          <span className="mono text-[11px] text-[#9A9AA0]">Payment: {method} • Stored in PostgreSQL</span>
        </div>
      )}

      <p className="mt-6 text-[18px] leading-[1.5] text-[#3F3F46]">Your order is saved in backend. PayPal: <span className="font-bold">{CONTACT.paypalEmail}</span>. Support: {CONTACT.supportEmail}. Phone: {CONTACT.phone}</p>

      {method === "paypal" && (
        <div className="mt-8 rounded-[24px] border border-[#E8E6DE] bg-[#E6FF3B] p-6 text-left">
          <div className="mono text-[11px] uppercase tracking-[0.12em]">PayPal Payment Instructions — Option A</div>
          <div className="mt-4 grid gap-3 text-[14px] leading-[1.5]">
            <div className="flex gap-3"><span className="mono text-[12px]">01</span><span>Send <span className="font-bold">${orderData?.order?.total || "amount"}</span> via PayPal to <span className="rounded-full bg-black px-2 py-0.5 text-[12px] font-bold text-[#E6FF3B]">{CONTACT.paypalEmail}</span></span></div>
            <div className="flex gap-3"><span className="mono text-[12px]">02</span><span>PayPal link: <a href={CONTACT.paypalLink} className="underline font-medium">{CONTACT.paypalLink}</a></span></div>
            <div className="flex gap-3"><span className="mono text-[12px]">03</span><span>Add order code <span className="font-bold">{code || "UP-XXXX"}</span> in PayPal notes</span></div>
            <div className="flex gap-3"><span className="mono text-[12px]">04</span><span>Verification within 2h. Confirmation email from {CONTACT.supportEmail}</span></div>
          </div>
          <div className="mt-4 flex gap-2">
            <a href={CONTACT.paypalLink} target="_blank" className="mono rounded-full bg-black px-5 py-2 text-[11px] uppercase tracking-[0.14em] text-white">Open PayPal → {CONTACT.paypalEmail}</a>
            <a href={`mailto:${CONTACT.supportEmail}?subject=PayPal%20Payment%20${code}`} className="mono rounded-full border border-black bg-white px-5 py-2 text-[11px] uppercase tracking-[0.14em] text-black">Email Support</a>
          </div>
        </div>
      )}

      <div className="mt-10 grid gap-4 rounded-[28px] border border-[#E8E6DE] bg-white p-6 text-left md:grid-cols-3">
        {[
          { k: "01", t: "Check Email", d: `Invite + Notion OS — from ${CONTACT.supportEmail}` },
          { k: "02", t: "Join Slack", d: `Private channel • Questions? Call ${CONTACT.phone}` },
          { k: "03", t: "Backend Verified", d: "Order stored in PostgreSQL • Admin can see it" },
        ].map((s) => (
          <div key={s.k} className="rounded-[16px] bg-[#F6F4EF] p-4">
            <div className="mono text-[11px] text-[#9A9AA0]">{s.k}</div>
            <div className="serif mt-1 text-[18px] font-medium">{s.t}</div>
            <div className="mt-1 text-[13px] text-[#6B6B73]">{s.d}</div>
          </div>
        ))}
      </div>

      <div className="mt-10 flex justify-center gap-3">
        <Link href="/shop" className="mono rounded-full border border-[#E8E6DE] bg-white px-6 py-3 text-[11px] uppercase tracking-[0.14em]">Back to Drops</Link>
        <Link href="/admin" className="mono rounded-full bg-black px-6 py-3 text-[11px] uppercase tracking-[0.14em] text-white">View in Admin Backend →</Link>
      </div>

      <div className="mt-8 rounded-[16px] border border-[#E8E6DE] bg-white p-4 text-left">
        <div className="mono mb-2 text-[11px] uppercase tracking-[0.12em] text-[#6B6B73]">Direct Contact — Option A</div>
        <div className="grid gap-2 text-[13px] md:grid-cols-3">
          <div>Contact: <a href={`tel:${CONTACT.phone}`} className="font-bold">{CONTACT.phone}</a></div>
          <div>PayPal: {CONTACT.paypalEmail}</div>
          <div>Support: {CONTACT.supportEmail}</div>
        </div>
      </div>
    </div>
  );
}

export default function SuccessPage() {
  return (
    <Suspense fallback={<div className="p-10 mono text-[11px] uppercase">Loading receipt...</div>}>
      <SuccessContent />
    </Suspense>
  );
}
