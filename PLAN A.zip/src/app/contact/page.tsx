"use client";
import { useState } from "react";
import { CONTACT } from "@/lib/constants";

export default function ContactPage() {
  const [form, setForm] = useState({ name: "", email: "", phone: "", subject: "", message: "" });
  const [sending, setSending] = useState(false);
  const [sent, setSent] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSending(true);
    const res = await fetch("/api/contact", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(form) });
    if (res.ok) {
      setSent(true);
      setForm({ name: "", email: "", phone: "", subject: "", message: "" });
    }
    setSending(false);
  };

  return (
    <div className="mx-auto max-w-[1600px] px-6 py-10 lg:px-10">
      <div className="grid gap-12 lg:grid-cols-[0.9fr_1.1fr]">
        <div>
          <div className="mono mb-4 inline-flex rounded-full bg-[#E6FF3B] px-3 py-1 text-[10px] uppercase tracking-[0.14em]">Option A — Backend Support Live</div>
          <h1 className="serif text-[52px] leading-[0.9] tracking-[-0.03em]">Contact<br/>Support.</h1>
          <p className="mt-6 text-[16px] leading-[1.6] text-[#3F3F46]">Backend stores every ticket in PostgreSQL. We reply within 2 hours. Direct line for urgent.</p>

          <div className="mt-10 space-y-4">
            <div className="rounded-[20px] border border-[#E8E6DE] bg-white p-6">
              <div className="mono text-[11px] uppercase tracking-[0.12em] text-[#6B6B73]">Direct Contact</div>
              <div className="mt-3 serif text-[28px] font-medium"><a href={`tel:${CONTACT.phone}`} className="hover:underline">{CONTACT.phone}</a></div>
              <div className="mono mt-1 text-[11px] uppercase tracking-[0.08em] text-[#9A9AA0]">Call / WhatsApp • 12h coverage • Mon-Sun</div>
              <a href={CONTACT.whatsapp} target="_blank" className="mono mt-4 inline-flex rounded-full bg-[#0F0F10] px-4 py-2 text-[11px] uppercase tracking-[0.12em] text-white">WhatsApp →</a>
            </div>

            <div className="rounded-[20px] bg-[#0F0F10] p-6 text-white">
              <div className="mono text-[11px] uppercase tracking-[0.12em] opacity-60">Payments via PayPal</div>
              <div className="mt-3 text-[18px] font-medium">{CONTACT.paypalEmail}</div>
              <div className="mono mt-2 text-[11px] opacity-60">Send with order code in notes • Verified in 2h • Link: {CONTACT.paypalLink}</div>
              <a href={CONTACT.paypalLink} target="_blank" className="mono mt-4 inline-flex rounded-full bg-white px-4 py-2 text-[11px] uppercase tracking-[0.12em] text-black">Open PayPal</a>
            </div>

            <div className="rounded-[20px] border border-[#E8E6DE] bg-[#F6F4EF] p-6">
              <div className="mono text-[11px] uppercase tracking-[0.12em] text-[#6B6B73]">Support Email</div>
              <div className="mt-3 text-[18px] font-medium">{CONTACT.supportEmail}</div>
              <div className="mono mt-2 text-[11px] text-[#9A9AA0]">Technical, billing, onboarding • Reply under 2h • Backend ticket system</div>
              <a href={`mailto:${CONTACT.supportEmail}`} className="mono mt-4 inline-flex rounded-full border border-[#E8E6DE] bg-white px-4 py-2 text-[11px] uppercase tracking-[0.12em]">Email Support</a>
            </div>

            <div className="rounded-[16px] bg-[#E6FF3B] p-4">
              <div className="mono text-[10px] uppercase tracking-[0.12em]">Backend Info</div>
              <p className="mt-2 text-[12px] leading-[1.4]">PostgreSQL + Drizzle ORM • Tables: products, orders, reviews, support_tickets • API: /api/products, /api/orders, /api/contact, /api/paypal, /api/seed • All data persisted, admin view at /admin</p>
            </div>
          </div>
        </div>

        <div className="rounded-[28px] border border-[#E8E6DE] bg-white p-7">
          <h3 className="serif text-[24px] font-medium">Send a ticket — goes to backend</h3>
          <p className="mono mt-2 text-[11px] uppercase tracking-[0.12em] text-[#6B6B73]">Stored in support_tickets table • Support {CONTACT.supportEmail} gets notified</p>

          {sent ? (
            <div className="mt-8 rounded-[20px] bg-[#0F0F10] p-8 text-center text-white">
              <div className="mx-auto grid h-12 w-12 place-items-center rounded-full bg-white text-black">✓</div>
              <p className="serif mt-4 text-[22px]">Ticket created in backend</p>
              <p className="mono mt-2 text-[11px] uppercase tracking-[0.12em] opacity-60">We’ve stored it in PostgreSQL • Reply to {CONTACT.supportEmail} within 2h • Or call {CONTACT.phone}</p>
              <button onClick={() => setSent(false)} className="mono mt-6 rounded-full bg-white px-5 py-2 text-[11px] uppercase tracking-[0.12em] text-black">Send Another</button>
            </div>
          ) : (
            <form onSubmit={submit} className="mt-8 space-y-4">
              <div className="grid gap-4 md:grid-cols-2">
                <div>
                  <label className="mono mb-2 block text-[11px] uppercase tracking-[0.12em]">Name</label>
                  <input required value={form.name} onChange={e => setForm({...form, name: e.target.value})} className="w-full rounded-full border border-[#E8E6DE] bg-[#FCFCF8] px-5 py-3 text-[14px] outline-none focus:border-black" placeholder="Maya Chen" />
                </div>
                <div>
                  <label className="mono mb-2 block text-[11px] uppercase tracking-[0.12em]">Phone — {CONTACT.phone}</label>
                  <input value={form.phone} onChange={e => setForm({...form, phone: e.target.value})} className="w-full rounded-full border border-[#E8E6DE] bg-[#FCFCF8] px-5 py-3 text-[14px] outline-none focus:border-black" placeholder={CONTACT.phone} />
                </div>
              </div>
              <div>
                <label className="mono mb-2 block text-[11px] uppercase tracking-[0.12em]">Email</label>
                <input required type="email" value={form.email} onChange={e => setForm({...form, email: e.target.value})} className="w-full rounded-full border border-[#E8E6DE] bg-[#FCFCF8] px-5 py-3 text-[14px] outline-none focus:border-black" placeholder="you@studio.com" />
              </div>
              <div>
                <label className="mono mb-2 block text-[11px] uppercase tracking-[0.12em]">Subject</label>
                <input value={form.subject} onChange={e => setForm({...form, subject: e.target.value})} className="w-full rounded-full border border-[#E8E6DE] bg-[#FCFCF8] px-5 py-3 text-[14px] outline-none focus:border-black" placeholder="Help with my order / PayPal / etc" />
              </div>
              <div>
                <label className="mono mb-2 block text-[11px] uppercase tracking-[0.12em]">Message</label>
                <textarea required value={form.message} onChange={e => setForm({...form, message: e.target.value})} rows={5} className="w-full rounded-[20px] border border-[#E8E6DE] bg-[#FCFCF8] px-5 py-4 text-[14px] outline-none focus:border-black" placeholder="How can we help? Include order code if PayPal..." />
              </div>

              <button disabled={sending} className="w-full rounded-full bg-[#0F0F10] py-4 text-[14px] font-medium text-white hover:bg-black disabled:opacity-60">
                {sending ? "Saving to backend..." : "Send Ticket → Backend • Support in 2h"}
              </button>

              <p className="mono text-center text-[10px] uppercase tracking-[0.1em] text-[#9A9AA0]">Stored in PostgreSQL • Contact {CONTACT.phone} for urgent • PayPal {CONTACT.paypalEmail} • Support {CONTACT.supportEmail}</p>
            </form>
          )}

          <div className="mt-8 grid gap-3 md:grid-cols-3">
            {[
              { k: "Avg Reply", v: "1h 24m" },
              { k: "Tickets", v: "1.2k solved" },
              { k: "Satisfaction", v: "4.9/5" },
            ].map(s => (
              <div key={s.k} className="rounded-[14px] bg-[#F6F4EF] p-4 text-center">
                <div className="serif text-[18px] font-medium">{s.v}</div>
                <div className="mono mt-1 text-[10px] uppercase tracking-[0.1em] text-[#6B6B73]">{s.k}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
