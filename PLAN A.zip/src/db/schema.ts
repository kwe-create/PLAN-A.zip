import { pgTable, text, integer, boolean, timestamp, jsonb, serial, numeric, varchar } from "drizzle-orm/pg-core";

export const products = pgTable("products", {
  id: text("id").primaryKey(),
  slug: varchar("slug", { length: 255 }).notNull().unique(),
  title: text("title").notNull(),
  subtitle: text("subtitle").notNull(),
  description: text("description").notNull(),
  longDescription: text("long_description").notNull(),
  price: integer("price").notNull(), // in dollars for simplicity
  compareAtPrice: integer("compare_at_price"),
  billing: varchar("billing", { length: 20 }).notNull(), // one-time | monthly | weekly
  category: varchar("category", { length: 50 }).notNull(),
  tags: jsonb("tags").$type<string[]>().notNull(),
  featured: boolean("featured").notNull().default(false),
  isNew: boolean("is_new").default(false),
  isBestSeller: boolean("is_best_seller").default(false),
  color: text("color").notNull(),
  accent: text("accent").notNull(),
  image: text("image").notNull(),
  gallery: jsonb("gallery").$type<string[]>().notNull(),
  features: jsonb("features").$type<string[]>().notNull(),
  includes: jsonb("includes").$type<string[]>().notNull(),
  metrics: jsonb("metrics").$type<{ label: string; value: string }[]>().notNull(),
  rating: numeric("rating", { precision: 3, scale: 2 }).notNull(),
  reviewCount: integer("review_count").notNull().default(0),
  delivery: text("delivery").notNull(),
  turnaround: text("turnaround").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const reviews = pgTable("reviews", {
  id: text("id").primaryKey(),
  productId: text("product_id").references(() => products.id, { onDelete: "cascade" }),
  author: text("author").notNull(),
  avatar: text("avatar").notNull(),
  handle: text("handle").notNull(),
  role: text("role").notNull(),
  rating: integer("rating").notNull(),
  date: text("date").notNull(),
  text: text("text").notNull(),
  followers: text("followers").notNull(),
  verified: boolean("verified").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  orderCode: varchar("order_code", { length: 20 }).notNull().unique(),
  customerName: text("customer_name").notNull(),
  email: text("email").notNull(),
  creatorHandle: text("creator_handle").notNull(),
  phone: varchar("phone", { length: 30 }),
  status: varchar("status", { length: 30 }).notNull().default("pending"),
  subtotal: integer("subtotal").notNull(),
  tax: integer("tax").notNull(),
  total: integer("total").notNull(),
  paymentMethod: varchar("payment_method", { length: 30 }).notNull().default("card"),
  paypalEmail: text("paypal_email").notNull().default("kbett8917@gmail.com"),
  items: jsonb("items").$type<{ productId: string; title: string; slug: string; price: number; quantity: number; image: string }[]>().notNull(),
  supportEmail: text("support_email").notNull().default("feliciarhodes@gmail.com"),
  contactPhone: varchar("contact_phone", { length: 30 }).notNull().default("0797533743"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const supportTickets = pgTable("support_tickets", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  phone: varchar("phone", { length: 30 }),
  subject: text("subject").notNull(),
  message: text("message").notNull(),
  status: varchar("status", { length: 20 }).notNull().default("open"),
  createdAt: timestamp("created_at").defaultNow(),
});
