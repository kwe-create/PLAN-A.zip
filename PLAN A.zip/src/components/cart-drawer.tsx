"use client";
import { useCart } from "./cart-context";
import { motion, AnimatePresence } from "framer-motion";
import Link from "next/link";
import { useEffect } from "react";

export function CartDrawer() {
  const { items, isOpen, closeCart, removeItem, updateQty, subtotal, count } = useCart();

  useEffect(() => {
    if (isOpen) document.body.style.overflow = "hidden";
    else document.body.style.overflow = "";
    return () => { document.body.style.overflow = ""; };
  }, [isOpen]);

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={closeCart}
            className="fixed inset-0 z-[60] bg-black/40 backdrop-blur-sm"
          />
          <motion.div
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            transition={{ type: "spring", damping: 28, stiffness: 220 }}
            className="fixed right-0 top-0 z-[70] flex h-[100dvh] w-full max-w-[480px] flex-col bg-[#FCFCF8] shadow-[-24px_0_80px_rgba(0,0,0,0.12)]"
          >
            <div className="flex h-[72px] items-center justify-between border-b border-[#E8E6DE] px-6">
              <div className="flex items-center gap-3">
                <span className="serif text-[22px] font-medium tracking-tight">Cart</span>
                <span className="mono grid h-6 min-w-6 place-items-center rounded-full bg-black px-2 text-[11px] text-white">{count}</span>
              </div>
              <button onClick={closeCart} className="grid h-9 w-9 place-items-center rounded-full border border-[#E8E6DE] bg-white text-[14px]">✕</button>
            </div>

            <div className="flex-1 overflow-y-auto px-6 py-6">
              {items.length === 0 ? (
                <div className="grid h-full place-items-center py-20 text-center">
                  <div>
                    <div className="mx-auto grid h-20 w-20 place-items-center rounded-full bg-[#F3F1EA] text-2xl">🛒</div>
                    <p className="serif mt-6 text-[24px] leading-tight">Your cart is quiet.</p>
                    <p className="mono mt-2 text-[12px] uppercase tracking-[0.12em] text-[#6B6B73]">Add a drop to start scaling</p>
                    <Link href="/shop" onClick={closeCart} className="mono mt-6 inline-flex rounded-full bg-black px-6 py-3 text-[11px] uppercase tracking-[0.14em] text-white">Browse Drops</Link>
                  </div>
                </div>
              ) : (
                <div className="space-y-5">
                  {items.map((item) => (
                    <div key={item.product.id} className="group flex gap-4 rounded-[20px] border border-[#E8E6DE] bg-white p-4">
                      <div className="h-[96px] w-[96px] shrink-0 overflow-hidden rounded-[14px] bg-[#F3F1EA]">
                        <img src={item.product.image} alt={item.product.title} className="h-full w-full object-cover" />
                      </div>
                      <div className="flex flex-1 flex-col">
                        <div className="flex items-start justify-between gap-3">
                          <div>
                            <p className="serif text-[16px] font-medium leading-[1.1]">{item.product.title}</p>
                            <p className="mono mt-1 text-[10px] uppercase tracking-[0.12em] text-[#6B6B73]">{item.product.billing} • {item.product.category}</p>
                          </div>
                          <button onClick={() => removeItem(item.product.id)} className="mono text-[11px] uppercase tracking-[0.12em] text-[#9A9AA0] hover:text-black">Remove</button>
                        </div>
                        <div className="mt-auto flex items-center justify-between">
                          <div className="flex items-center gap-2 rounded-full border border-[#E8E6DE] bg-[#FCFCF8] px-1 py-1">
                            <button onClick={() => updateQty(item.product.id, item.quantity - 1)} className="grid h-6 w-6 place-items-center rounded-full bg-white text-[14px]">−</button>
                            <span className="mono w-6 text-center text-[12px]">{item.quantity}</span>
                            <button onClick={() => updateQty(item.product.id, item.quantity + 1)} className="grid h-6 w-6 place-items-center rounded-full bg-white text-[14px]">+</button>
                          </div>
                          <span className="serif text-[16px] font-medium">${item.product.price.toLocaleString()}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {items.length > 0 && (
              <div className="border-t border-[#E8E6DE] bg-white p-6">
                <div className="flex items-center justify-between">
                  <span className="mono text-[11px] uppercase tracking-[0.12em] text-[#6B6B73]">Subtotal</span>
                  <span className="serif text-[22px] font-medium">${subtotal.toLocaleString()}</span>
                </div>
                <p className="mono mt-2 text-[10px] leading-[1.5] text-[#9A9AA0] uppercase tracking-[0.08em]">Tax & setup included at checkout. Cancel anytime. 48h kickoff for retainers.</p>
                <Link href="/checkout" onClick={closeCart} className="mt-4 flex w-full items-center justify-center gap-2 rounded-full bg-[#0F0F10] py-4 text-[13px] font-medium text-white transition hover:bg-black">
                  Checkout → <span className="mono text-[11px] opacity-60">(${subtotal.toLocaleString()})</span>
                </Link>
                <div className="mt-3 flex justify-center gap-2">
                  <span className="h-6 w-10 rounded border border-[#E8E6DE] bg-[#FCFCF8]"></span>
                  <span className="h-6 w-10 rounded border border-[#E8E6DE] bg-[#FCFCF8]"></span>
                  <span className="h-6 w-10 rounded border border-[#E8E6DE] bg-[#FCFCF8]"></span>
                  <span className="mono text-[10px] uppercase tracking-[0.12em] text-[#9A9AA0] ml-2 mt-1">Secure Checkout</span>
                </div>
              </div>
            )}
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
