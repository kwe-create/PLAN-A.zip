"use client";
import { Product } from "@/data/products";
import Link from "next/link";
import { useCart } from "./cart-context";
import { motion } from "framer-motion";

export function ProductCard({ product, index = 0 }: { product: Product; index?: number }) {
  const { addItem } = useCart();
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-100px" }}
      transition={{ delay: index * 0.06, duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
      className="group relative flex flex-col overflow-hidden rounded-[28px] border border-[#E8E6DE] bg-white"
    >
      <Link href={`/product/${product.slug}`} className="block">
        <div className="relative aspect-[4/3] overflow-hidden bg-[#F6F4EF]">
          <img src={product.image} alt={product.title} className="h-full w-full object-cover transition duration-[1.2s] ease-[cubic-bezier(0.22,1,0.36,1)] group-hover:scale-[1.06]" />
          <div className="absolute left-4 top-4 flex gap-2">
            {product.isBestSeller && <span className="mono rounded-full bg-black px-3 py-1 text-[10px] uppercase tracking-[0.12em] text-white">Best Seller</span>}
            {product.isNew && <span className="mono rounded-full bg-[#E6FF3B] px-3 py-1 text-[10px] uppercase tracking-[0.12em] text-black">New Drop</span>}
            {product.compareAtPrice && <span className="mono rounded-full bg-[#FF3B1F] px-3 py-1 text-[10px] uppercase tracking-[0.12em] text-white">Save ${(product.compareAtPrice - product.price).toLocaleString()}</span>}
          </div>
          <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between">
            <div className="flex items-center gap-1.5 rounded-full bg-white/90 px-3 py-1.5 backdrop-blur-md">
              <span className="text-[12px]">★</span>
              <span className="mono text-[11px] font-medium">{product.rating}</span>
              <span className="mono text-[10px] text-[#6B6B73]">({product.reviewCount})</span>
            </div>
            <div className="mono rounded-full bg-white/90 px-3 py-1.5 text-[10px] uppercase tracking-[0.12em] backdrop-blur-md">{product.delivery}</div>
          </div>
        </div>
      </Link>

      <div className="flex flex-1 flex-col p-6">
        <div className="mb-3 flex items-start justify-between gap-4">
          <div>
            <Link href={`/product/${product.slug}`}>
              <h3 className="serif text-[21px] font-[550] leading-[1.05] tracking-[-0.015em] transition group-hover:tracking-[-0.01em]">{product.title}</h3>
            </Link>
            <p className="mono mt-1 text-[11px] uppercase tracking-[0.1em] text-[#6B6B73]">{product.category} • {product.billing}</p>
          </div>
          <div className="text-right">
            <div className="serif text-[20px] font-medium leading-none">${product.price.toLocaleString()}</div>
            {product.compareAtPrice && <div className="mono mt-1 text-[11px] text-[#A0A0A8] line-through">${product.compareAtPrice.toLocaleString()}</div>}
          </div>
        </div>

        <p className="line-clamp-2 text-[14px] leading-[1.5] text-[#3F3F46]">{product.subtitle}</p>

        <div className="mt-4 flex flex-wrap gap-1.5">
          {product.tags.slice(0, 3).map((t) => (
            <span key={t} className="mono rounded-full border border-[#E8E6DE] bg-[#FCFCF8] px-2.5 py-1 text-[10px] uppercase tracking-[0.08em] text-[#6B6B73]">{t}</span>
          ))}
        </div>

        <div className="mt-6 flex items-center gap-2">
          <button onClick={() => addItem(product)} className="flex-1 rounded-full bg-[#0F0F10] py-[12px] text-[13px] font-medium text-white transition hover:bg-black active:scale-[0.98]">Add to Cart</button>
          <Link href={`/product/${product.slug}`} className="grid h-[44px] w-[44px] place-items-center rounded-full border border-[#E8E6DE] bg-white transition hover:bg-[#F6F4EF]">↗</Link>
        </div>

        <div className="mt-4 grid grid-cols-3 gap-2 border-t border-[#F0EDE6] pt-4">
          {product.metrics.slice(0, 3).map((m) => (
            <div key={m.label}>
              <div className="serif text-[16px] font-medium leading-none">{m.value}</div>
              <div className="mono mt-1 text-[9px] uppercase tracking-[0.1em] text-[#8B8B93]">{m.label}</div>
            </div>
          ))}
        </div>
      </div>
    </motion.div>
  );
}
