export const CONTACT = {
  phone: "0797533743",
  phoneDisplay: "0797 533 743",
  paypalEmail: "kbett8917@gmail.com",
  supportEmail: "feliciarhodes@gmail.com",
  paypalLink: "https://paypal.me/kbett8917",
  whatsapp: "https://wa.me/44797533743",
} as const;

export const STORE = {
  name: "UPSCORE",
  tagline: "Social management for creators who mean business",
  location: "Los Angeles — Remote / Worldwide",
  founded: "2023",
} as const;
