import { CONTACT } from "@/lib/constants";

export const dynamic = "force-dynamic";

export async function GET() {
  return Response.json({
    provider: "PayPal",
    email: CONTACT.paypalEmail,
    link: CONTACT.paypalLink,
    support: CONTACT.supportEmail,
    phone: CONTACT.phone,
    instructions: [
      `Send payment to PayPal: ${CONTACT.paypalEmail}`,
      `Use link: ${CONTACT.paypalLink}`,
      `Include your order code in PayPal notes`,
      `For issues contact support at ${CONTACT.supportEmail} or call ${CONTACT.phone}`
    ],
    qr: `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(CONTACT.paypalLink)}`
  });
}

export async function POST(req: Request) {
  const body = await req.json().catch(() => ({}));
  const { amount, orderCode } = body;
  // Simulate creating paypal payment intent
  return Response.json({
    success: true,
    payment: {
      provider: "paypal",
      paypalEmail: CONTACT.paypalEmail,
      amount,
      orderCode,
      paypalLink: `${CONTACT.paypalLink}/${amount || ""}`,
      status: "pending_verification",
      nextSteps: `Send $${amount || "total"} to ${CONTACT.paypalEmail} with note "${orderCode || "UPSCORE order"}". Verification within 2h. Support: ${CONTACT.supportEmail}`
    }
  });
}
