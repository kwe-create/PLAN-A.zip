import { db } from "@/db";
import { supportTickets } from "@/db/schema";
import { desc } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const tickets = await db.select().from(supportTickets).orderBy(desc(supportTickets.createdAt)).limit(100);
    return Response.json({ tickets });
  } catch (e) {
    return Response.json({ error: "Failed" }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { name, email, phone, subject, message } = body;
    if (!name || !email || !message) return Response.json({ error: "Missing fields" }, { status: 400 });

    const [ticket] = await db.insert(supportTickets).values({
      name,
      email,
      phone: phone || "",
      subject: subject || "General Inquiry",
      message,
      status: "open",
    }).returning();

    return Response.json({ success: true, ticket, contact: {
      phone: "0797533743",
      supportEmail: "feliciarhodes@gmail.com",
      paypalEmail: "kbett8917@gmail.com"
    }});
  } catch (e) {
    console.error(e);
    return Response.json({ error: "Failed to create ticket" }, { status: 500 });
  }
}
