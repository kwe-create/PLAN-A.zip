"use client";
import { useParams } from "next/navigation";
import { products } from "@/data/products";
import { useCart } from "@/components/cart-context";
import { useState } from "react";
import Link from "next/link";
import { motion } from "framer-motion";

export default function ProductDetailPage() {
  const params = useParams();
  const slug = params.slug as string;
  const product = products.find((p) => p.slug === slug);
  const { addItem } = useCart();
  const [activeImg, setActiveImg] = useState(0);
  const [qty, setQty] = useState(1);
  const [tab, setTab] = useState<"includes" | "process" | "reviews">("includes");

  if (!product) {
    return (
      <div className="mx-auto max-w-[1600px] px-6 py-20 lg:px-10">
        <p className="serif text-[32px]">Drop not found</p>
        <Link href="/shop" className="mono mt-4 inline-flex rounded-full bg-black px-6 py-3 text-[11px] uppercase tracking-[0.14em] text-white">Back to Shop</Link>
      </div>
    );
  }

  const related = products.filter((p) => p.category === product.category && p.id !== product.id).slice(0, 3);

  return (
    <div className="mx-auto max-w-[1600px] px-6 py-8 lg:px-10 lg:py-10">
      <div className="mono mb-6 flex items-center gap-2 text-[11px] uppercase tracking-[0.12em] text-[#6B6B73]">
        <Link href="/" className="hover:text-black">Home</Link><span>/</span><Link href="/shop" className="hover:text-black">Shop</Link><span>/</span><span className="text-black">{product.title}</span>
      </div>

      <div className="grid gap-10 lg:grid-cols-[1.15fr_0.85fr]">
        {/* Gallery */}
        <div className="space-y-4">
          <div className="relative aspect-[4/3] overflow-hidden rounded-[28px] border border-[#E8E6DE] bg-[#F6F4EF]">
            <img src={product.gallery[activeImg]} alt={product.title} className="h-full w-full object-cover" />
            <div className="absolute left-4 top-4 flex gap-2">
              {product.isBestSeller && <span className="mono rounded-full bg-black px-3 py-1 text-[10px] uppercase tracking-[0.12em] text-white">Best Seller</span>}
              <span className="mono rounded-full bg-white/90 px-3 py-1 text-[10px] uppercase tracking-[0.12em] backdrop-blur">{product.delivery}</span>
            </div>
            <div className="absolute bottom-4 right-4 flex gap-2">
              {product.metrics.map((m) => (
                <div key={m.label} className="rounded-full bg-white/90 px-3 py-1.5 backdrop-blur">
                  <span className="serif text-[13px] font-medium">{m.value}</span> <span className="mono text-[10px] uppercase tracking-[0.08em] text-[#6B6B73]">{m.label}</span>
                </div>
              ))}
            </div>
          </div>
          <div className="flex gap-3">
            {product.gallery.map((img, i) => (
              <button key={i} onClick={() => setActiveImg(i)} className={`relative h-[72px] w-[96px] overflow-hidden rounded-[14px] border ${activeImg === i ? "border-black" : "border-[#E8E6DE] opacity-70 hover:opacity-100"}`}>
                <img src={img} alt="" className="h-full w-full object-cover" />
              </button>
            ))}
          </div>

          <div className="rounded-[24px] border border-[#E8E6DE] bg-white p-6">
            <div className="flex gap-2 border-b border-[#E8E6DE] pb-4">
              {[
                { id: "includes", label: "What's Included" },
                { id: "process", label: "Process" },
                { id: "reviews", label: `Reviews (${product.reviewCount})` },
              ].map((t) => (
                <button key={t.id} onClick={() => setTab(t.id as any)} className={`mono rounded-full px-4 py-2 text-[11px] uppercase tracking-[0.12em] transition ${tab === t.id ? "bg-black text-white" : "bg-[#F6F4EF] text-[#6B6B73] hover:bg-[#E8E6DE]"}`}>{t.label}</button>
              ))}
            </div>

            <div className="pt-6">
              {tab === "includes" && (
                <div className="grid gap-6 md:grid-cols-2">
                  <div>
                    <p className="mono mb-3 text-[11px] uppercase tracking-[0.12em] text-[#6B6B73]">Features</p>
                    <ul className="space-y-2">
                      {product.features.map((f) => (
                        <li key={f} className="flex gap-2 text-[14px] leading-[1.4]"><span className="mt-1 h-1.5 w-1.5 shrink-0 rounded-full bg-black"/> {f}</li>
                      ))}
                    </ul>
                  </div>
                  <div>
                    <p className="mono mb-3 text-[11px] uppercase tracking-[0.12em] text-[#6B6B73]">Includes</p>
                    <ul className="space-y-2">
                      {product.includes.map((f) => (
                        <li key={f} className="flex gap-2 text-[14px] leading-[1.4]"><span className="mono text-[12px]">↳</span> {f}</li>
                      ))}
                    </ul>
                  </div>
                </div>
              )}
              {tab === "process" && (
                <div className="space-y-4">
                  <div className="grid gap-4 md:grid-cols-3">
                    {[
                      { n: "01", t: "Kickoff", d: "45-min call, access to your accounts, audit in 24h." },
                      { n: "02", t: "Install", d: "We build your system inside Slack + Notion, Loom walkthrough." },
                      { n: "03", t: "Grow", d: "Daily execution + weekly reporting. Scale check every 14 days." },
                    ].map((s) => (
                      <div key={s.n} className="rounded-2xl bg-[#F6F4EF] p-4">
                        <div className="mono text-[11px] text-[#9A9AA0]">{s.n}</div>
                        <div className="serif mt-1 text-[18px] font-medium">{s.t}</div>
                        <div className="mt-2 text-[13px] leading-[1.4] text-[#6B6B73]">{s.d}</div>
                      </div>
                    ))}
                  </div>
                  <div className="rounded-2xl bg-[#0F0F10] p-5 text-white">
                    <span className="mono text-[11px] uppercase tracking-[0.12em] opacity-60">Delivery</span>
                    <p className="mt-2 text-[14px] leading-[1.5]">Kickoff in {product.delivery.toLowerCase()} — most clients see first lift within 7–14 days. Cancel anytime. No long-term contracts. Average client stays 8.3 months because it works.</p>
                  </div>
                </div>
              )}
              {tab === "reviews" && (
                <div className="space-y-6">
                  <div className="flex items-center gap-4">
                    <div className="serif text-[48px] leading-none">{product.rating}</div>
                    <div>
                      <div className="text-[#E6FF00]">{"★".repeat(5)}</div>
                      <div className="mono mt-1 text-[11px] uppercase tracking-[0.12em] text-[#6B6B73]">{product.reviewCount} verified creator reviews</div>
                    </div>
                  </div>
                  <div className="grid gap-4">
                    {product.reviews.length === 0 ? <p className="text-[14px] text-[#6B6B73]">Reviews for this drop live on checkout — we audit every testimonial.</p> : product.reviews.map((r) => (
                      <div key={r.id} className="rounded-[16px] border border-[#E8E6DE] bg-[#FCFCF8] p-4">
                        <div className="flex items-center gap-3">
                          <img src={r.avatar} alt={r.author} className="h-9 w-9 rounded-full" />
                          <div>
                            <div className="flex items-center gap-2"><span className="text-[14px] font-medium">{r.author}</span>{r.verified && <span className="grid h-4 w-4 place-items-center rounded-full bg-[#0F0F10] text-[10px] text-white">✓</span>}<span className="mono text-[11px] text-[#6B6B73]">{r.handle}</span></div>
                            <div className="mono text-[11px] text-[#6B6B73]">{r.role} • {r.date}</div>
                          </div>
                          <div className="ml-auto mono text-[11px]">{r.rating}★</div>
                        </div>
                        <p className="mt-3 text-[14px] leading-[1.5]">“{r.text}”</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Info */}
        <div className="lg:sticky lg:top-[88px] lg:h-fit">
          <div className="rounded-[28px] border border-[#E8E6DE] bg-white p-7">
            <div className="mono mb-3 flex items-center gap-2 text-[11px] uppercase tracking-[0.12em] text-[#6B6B73]">
              <span className="rounded-full border border-[#E8E6DE] bg-[#F6F4EF] px-2.5 py-1">{product.category}</span>
              <span className="rounded-full border border-[#E8E6DE] bg-[#F6F4EF] px-2.5 py-1">{product.billing}</span>
              <span>•</span>
              <span>{product.turnaround}</span>
            </div>

            <h1 className="serif text-[36px] font-[600] leading-[0.95] tracking-[-0.02em] md:text-[44px]">{product.title}</h1>
            <p className="mt-3 text-[16px] leading-[1.4] text-[#3F3F46]">{product.subtitle}</p>

            <div className="mt-6 flex items-baseline gap-3">
              <span className="serif text-[36px] font-medium">${product.price.toLocaleString()}</span>
              {product.compareAtPrice && <span className="mono text-[14px] text-[#9A9AA0] line-through">${product.compareAtPrice.toLocaleString()}</span>}
              <span className="mono ml-auto text-[11px] uppercase tracking-[0.12em] text-[#6B6B73]">{product.billing === "one-time" ? "one-time" : "per month"}</span>
            </div>

            <p className="mt-6 text-[15px] leading-[1.6] text-[#3F3F46]">{product.description}</p>
            <p className="mt-4 text-[14px] leading-[1.6] text-[#6B6B73]">{product.longDescription}</p>

            <div className="mt-6 grid grid-cols-3 gap-3 border-y border-[#E8E6DE] py-5">
              {product.metrics.map((m) => (
                <div key={m.label} className="text-center">
                  <div className="serif text-[22px] font-medium">{m.value}</div>
                  <div className="mono mt-1 text-[10px] uppercase tracking-[0.1em] text-[#6B6B73]">{m.label}</div>
                </div>
              ))}
            </div>

            <div className="mt-6 flex items-center gap-3">
              <div className="flex items-center gap-2 rounded-full border border-[#E8E6DE] bg-[#FCFCF8] px-2 py-1">
                <button onClick={() => setQty((q) => Math.max(1, q - 1))} className="grid h-8 w-8 place-items-center rounded-full bg-white">−</button>
                <span className="mono w-6 text-center text-[14px]">{qty}</span>
                <button onClick={() => setQty((q) => q + 1)} className="grid h-8 w-8 place-items-center rounded-full bg-white">+</button>
              </div>
              <button onClick={() => addItem(product, qty)} className="flex-1 rounded-full bg-[#0F0F10] py-4 text-[14px] font-medium text-white transition hover:bg-black">Add to Cart — ${(product.price * qty).toLocaleString()}</button>
            </div>

            <div className="mono mt-4 grid grid-cols-2 gap-2 text-[10px] uppercase tracking-[0.1em] text-[#9A9AA0]">
              <div className="flex items-center gap-1.5"><span className="h-1.5 w-1.5 rounded-full bg-[#22C55E]"/> 483 live clients now</div>
              <div className="flex items-center gap-1.5"><span className="h-1.5 w-1.5 rounded-full bg-black"/> Cancel anytime</div>
              <div>✓ 48h kickoff</div>
              <div>✓ Private Slack</div>
            </div>

            <div className="mt-6 rounded-[16px] bg-[#F6F4EF] p-4">
              <div className="flex items-center gap-2">
                <div className="flex -space-x-1">
                  {[10, 11, 12].map((i) => (<img key={i} src={`https://i.pravatar.cc/80?img=${i}`} className="h-6 w-6 rounded-full border-2 border-[#F6F4EF]" alt="" />))}
                </div>
                <span className="mono text-[11px] text-[#6B6B73]">{product.reviewCount} creators bought this drop • 4.9/5 avg</span>
              </div>
            </div>
          </div>

          <div className="mt-4 rounded-[20px] border border-[#E8E6DE] bg-[#E6FF3B] p-5">
            <div className="mono text-[11px] uppercase tracking-[0.12em]">Guarantee</div>
            <p className="serif mt-2 text-[18px] leading-[1.2]">If you don’t see lift in 30 days, we work free until you do. No questions.</p>
          </div>
        </div>
      </div>

      {related.length > 0 && (
        <div className="mt-20 border-t border-[#E8E6DE] pt-12">
          <h3 className="serif text-[28px] font-medium">More in {product.category}</h3>
          <div className="mt-6 grid gap-5 md:grid-cols-3">
            {related.map((p) => (
              <Link key={p.id} href={`/product/${p.slug}`} className="group rounded-[20px] border border-[#E8E6DE] bg-white p-4 transition hover:border-black">
                <div className="aspect-[4/3] overflow-hidden rounded-[14px] bg-[#F6F4EF]">
                  <img src={p.image} alt={p.title} className="h-full w-full object-cover transition group-hover:scale-[1.03]" />
                </div>
                <div className="mt-3 flex items-start justify-between">
                  <div><div className="serif text-[16px] font-medium">{p.title}</div><div className="mono text-[11px] uppercase tracking-[0.08em] text-[#6B6B73]">{p.subtitle.slice(0, 46)}…</div></div>
                  <div className="serif text-[14px] font-medium">${p.price.toLocaleString()}</div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
